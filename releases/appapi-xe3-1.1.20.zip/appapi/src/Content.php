<?php
namespace Xpressengine\Plugins\Appapi;

use XeMenu;
use Xpressengine\Plugins\Board\Models\Board;
use Xpressengine\Plugins\Board\Models\BoardSlug;

/**
 * 엔진이 그린 본문 HTML 을 앱에서 그릴 수 있게 손본다 (글·댓글·페이지·위젯 페이지).
 * - 편집 도구 compile(saveHTML)이 겹쳐 넣는 <html><body> 껍데기를 벗긴다
 * - 지도 도구(naver·google·daum_map_tool)의 빈 상자 + jQuery 스크립트를 '지도 보기' 링크로 바꾼다
 *   (앱에는 지도 스크립트·열쇠가 없어 예전 앱에서도 빈 600px 상자였다 → 바꿔도 잃는 것이 없다)
 * - XE3 글 주소(/mid/<슬러그>, /mid/show/<uuid>, /mid/num/<번호>, /archives/<슬러그>)에 ?mid=…&document_srl=… 을 붙인다
 *   (앱은 쿼리의 mid·document_srl 을 먼저 보므로 예전 앱도 글 화면으로 연다. 웹은 모르는 쿼리를 무시한다)
 */
class Content
{
    /** 링크를 풀어 볼 최대 수 (본문 하나에서) */
    const MAX_LINKS = 100;

    public static function clean($html)
    {
        $html = (string)$html;
        if ($html === '') {
            return $html;
        }
        if (stripos($html, '<html') !== false || stripos($html, '<body') !== false || stripos($html, '<!doctype') !== false) {
            $html = preg_replace('#<!doctype[^>]*>|</?(?:html|body)\b[^>]*>#i', '', $html);
        }
        if (stripos($html, 'editortool/') !== false) {
            $html = self::maps($html);
        }
        return self::links($html);
    }

    // ---- 지도

    /** 지도 도구 상자 → '📍 장소 — 지도 보기' 링크 (좌표가 없으면 상자만 지운다) */
    private static function maps($html)
    {
        $pattern = '#<div\b(?=[^>]*\bxe-tool-id\s*=\s*["\']editortool/(navermap|googlemap|daummap)@[\w-]+["\'])([^>]*)>(.*?)</div>#is';
        return preg_replace_callback($pattern, function ($m) {
            $data = [];
            if (preg_match('#\bxe-tool-data\s*=\s*"([^"]*)"#i', $m[2], $d) || preg_match("#\\bxe-tool-data\\s*=\\s*'([^']*)'#i", $m[2], $d)) {
                $data = self::toolData($d[1]);
            }
            $lat = isset($data['lat']) && is_numeric($data['lat']) ? (float)$data['lat'] : null;
            $lng = isset($data['lng']) && is_numeric($data['lng']) ? (float)$data['lng'] : null;
            if ($lat === null || $lng === null || abs($lat) > 90 || abs($lng) > 180) {
                return '';
            }
            $text = trim(strip_tags((string)($data['text'] ?? '')));
            $url = self::mapUrl($m[1], $text, $lat, $lng);
            $label = $text !== '' ? Text::t('{0} — 지도 보기', $text) : Text::t('지도 보기');
            return '<p class="bh-map" data-bh-map="' . e($m[1]) . '" data-lat="' . $lat . '" data-lng="' . $lng . '">'
                . '<a href="' . e($url) . '">📍 ' . e($label) . '</a></p>';
        }, $html);
    }

    /** xe-tool-data: {'width':'600px','text':'…','lat':37.5,'lng':126.9,'zoom':15} (작은따옴표 JSON) */
    private static function toolData($raw)
    {
        $raw = html_entity_decode($raw, ENT_QUOTES, 'UTF-8');
        $json = json_decode($raw, true);
        if (!is_array($json)) {
            $json = json_decode(str_replace("'", '"', $raw), true);
        }
        if (is_array($json)) {
            return $json;
        }
        $out = [];
        foreach (['lat', 'lng'] as $key) {
            if (preg_match("#['\"]" . $key . "['\"]\\s*:\\s*['\"]?(-?[0-9.]+)#", $raw, $m)) {
                $out[$key] = $m[1];
            }
        }
        if (preg_match("#['\"]text['\"]\\s*:\\s*['\"]([^'\"]*)#u", $raw, $m)) {
            $out['text'] = $m[1];
        }
        return $out;
    }

    /** 좌표로 여는 지도 주소. 구글 지도는 구글, 네이버·다음 지도는 좌표·이름을 함께 받는 카카오맵 링크 */
    private static function mapUrl($tool, $text, $lat, $lng)
    {
        if ($tool === 'googlemap') {
            return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($lat . ',' . $lng);
        }
        $name = $text !== '' ? str_replace(',', ' ', $text) : $lat . ' ' . $lng;
        return 'https://map.kakao.com/link/map/' . rawurlencode($name) . ',' . $lat . ',' . $lng;
    }

    // ---- 글 링크

    /** 같은 사이트의 XE3 글 주소에 mid·document_srl 쿼리를 붙인다 */
    private static function links($html)
    {
        if (stripos($html, 'href') === false) {
            return $html;
        }
        $count = 0;
        return preg_replace_callback('#(<a\b[^>]*?\bhref\s*=\s*)(["\'])(.*?)\2#is', function ($m) use (&$count) {
            if (++$count > self::MAX_LINKS) {
                return $m[0];
            }
            $href = html_entity_decode($m[3], ENT_QUOTES, 'UTF-8');
            $found = self::documentOfUrl($href);
            if (!$found || !$found['document_srl']) {
                return $m[0];
            }
            $query = 'mid=' . rawurlencode($found['mid']) . '&document_srl=' . $found['document_srl'];
            $hash = '';
            if (($p = strpos($href, '#')) !== false) {
                $hash = substr($href, $p);
                $href = substr($href, 0, $p);
            }
            $href .= (strpos($href, '?') === false ? '?' : '&') . $query . $hash;
            return $m[1] . $m[2] . e($href) . $m[2];
        }, $html);
    }

    /**
     * 같은 사이트 주소 → ['item' => 메뉴 항목, 'mid', 'document_srl' (글이 아니면 0)]. 이 사이트 주소가 아니거나 모르는 꼴이면 null.
     * 권한은 보지 않는다 (resolve 와 같다. 실제 열람은 document 가 검사한다).
     */
    public static function documentOfUrl($url)
    {
        $url = trim((string)$url);
        if ($url === '' || $url[0] === '#' || preg_match('#^(mailto|tel|sms|javascript|data):#i', $url)) {
            return null;
        }
        $parts = parse_url($url);
        if ($parts === false) {
            return null;
        }
        $base = parse_url(url('/'));
        if (isset($parts['host'])) {
            $host = strtolower(preg_replace('/^(www|m)\.(?=[^.]+\.[^.]+)/i', '', $parts['host']));
            $siteHost = strtolower(preg_replace('/^(www|m)\.(?=[^.]+\.[^.]+)/i', '', (string)($base['host'] ?? '')));
            if ($host !== $siteHost) {
                return null;
            }
        } elseif (!isset($parts['path']) || $parts['path'] === '' || $parts['path'][0] !== '/') {
            return null; // 상대 주소(경로 없이 쓴 것)는 풀지 않는다
        }
        if (isset($parts['query'])) {
            parse_str($parts['query'], $q);
            if (isset($q['document_srl'])) {
                return null; // 이미 앱이 아는 꼴
            }
        }
        return self::documentOfPath((string)($parts['path'] ?? '/'));
    }

    /** 경로 → 위와 같은 값. /mid, /mid/<슬러그>, /mid/show/<uuid>, /mid/num/<번호>, /archives/<슬러그> */
    public static function documentOfPath($path)
    {
        $basePath = rtrim((string)(parse_url(url('/'), PHP_URL_PATH) ?: ''), '/');
        if ($basePath !== '' && strpos($path, $basePath . '/') === 0) {
            $path = substr($path, strlen($basePath));
        }
        $segments = array_values(array_filter(array_map('rawurldecode', explode('/', $path)), function ($s) {
            return $s !== '' && $s !== 'index.php';
        }));
        if (!$segments || count($segments) > 3) {
            return null;
        }
        $doc = null;
        if ($segments[0] === 'archives') {
            if (count($segments) !== 2) {
                return null;
            }
            $slug = BoardSlug::where('slug', $segments[1])->first();
            $doc = $slug ? Board::find($slug->target_id) : null;
            $item = $doc ? XeMenu::items()->find($doc->instance_id) : null;
            return $item ? self::found($item, $doc) : null;
        }
        if (!preg_match('/^[A-Za-z0-9_\-]{1,80}$/', $segments[0])) {
            return null;
        }
        $item = XeMenu::items()->query()->where('url', $segments[0])->first();
        if (!$item) {
            return null;
        }
        if (count($segments) === 1) {
            return self::found($item, null);
        }
        if ($item->type !== Boards::BOARD) {
            return null;
        }
        if (count($segments) === 3 && $segments[1] === 'show') {
            $doc = Board::where('id', $segments[2])->where('instance_id', $item->id)->first();
        } elseif (count($segments) === 3 && $segments[1] === 'num' && ctype_digit($segments[2])) {
            $slug = BoardSlug::where('id', (int)$segments[2])->where('instance_id', $item->id)->first();
            $doc = $slug ? Board::find($slug->target_id) : null;
        } elseif (count($segments) === 2) {
            // 웹의 /mid/{slug} 와 같다 (숫자만 있는 슬러그도 슬러그다)
            $slug = BoardSlug::where('slug', $segments[1])->where('instance_id', $item->id)->first();
            $doc = $slug ? Board::find($slug->target_id) : null;
        }
        if (!$doc || $doc->instance_id !== $item->id) {
            return null;
        }
        return self::found($item, $doc);
    }

    private static function found($item, $doc)
    {
        return ['item' => $item, 'mid' => (string)$item->url, 'document_srl' => $doc ? Store::num($doc->id) : 0];
    }
}
