@section('page_title')
    <h2>게시판모아 앱 연동</h2>
@endsection

@section('page_description')
    <small>게시판모아(BoardMoa) 앱에서 이 사이트의 게시판을 보고 쓸 수 있게 하는 플러그인입니다. (XE3용 시험판)</small>
@stop

<div class="row">
    <div class="col-sm-12">
        <div class="panel-group">
            <div class="panel">
                <div class="panel-heading">
                    <div class="pull-left"><h3 class="panel-title">버전과 업데이트</h3></div>
                </div>
                <div class="panel-body">
                    @if ($result)
                        <div class="alert {{ $result['ok'] ? 'alert-success' : 'alert-danger' }}">
                            {{ $result['message'] }}
                            @if (!empty($result['backup']))<br><small>이전 파일 백업: {{ $result['backup'] }}</small>@endif
                        </div>
                    @endif

                    <p>설치된 버전: <strong>{{ $current }}</strong></p>

                    @if ($check)
                        @if ($check['error'])
                            <div class="alert alert-warning">{{ $check['error'] }}</div>
                        @elseif ($check['has_update'])
                            <p>새 버전: <strong>{{ $check['latest'] }}</strong> ({{ $check['date'] }})</p>
                            @if ($check['notes'])<p style="white-space:pre-line">{{ $check['notes'] }}</p>@endif
                            @if (!$check['zip_available'])
                                <div class="alert alert-warning">서버의 PHP에 zip 확장 기능(ZipArchive)이 없어서 자동 업데이트를 할 수 없습니다. 공개 저장소에서 새 버전을 내려받아 plugins/appapi 폴더를 직접 바꿔 주세요.</div>
                            @elseif (!$check['writable'])
                                <div class="alert alert-warning">플러그인 폴더의 다음 파일에 쓰기 권한이 없습니다: {{ implode(', ', array_slice($check['problems'], 0, 3)) }}</div>
                            @else
                                <form method="post" action="{{ route('appapi::settings.update') }}" onsubmit="this.querySelector('button').disabled=true">
                                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <button type="submit" class="xe-btn xe-btn-primary">{{ $check['latest'] }} 버전으로 업데이트</button>
                                    <small class="text-muted">내려받은 파일의 전자서명을 확인하고, 지금 파일을 백업한 다음 새 파일로 바꿉니다.</small>
                                </form>
                            @endif
                        @elseif ($check['is_newer'])
                            <p class="text-muted">공개된 최신 버전({{ $check['latest'] }})보다 새 버전이 설치되어 있습니다.</p>
                        @else
                            <p class="text-success">최신 버전입니다.</p>
                        @endif
                    @else
                        <a href="{{ route('appapi::settings', ['check' => 1]) }}" class="xe-btn xe-btn-default">업데이트 확인</a>
                    @endif

                    <hr>
                    <h4>설치 현황 — 개발자에게 알리기</h4>
                    <form method="post" action="{{ route('appapi::settings.share') }}">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <input type="hidden" name="share_site" value="N">
                        <label><input type="checkbox" name="share_site" value="Y" {{ $shareSite ? 'checked' : '' }} onchange="this.form.submit()"> 업데이트를 확인할 때 이 사이트 정보를 개발자에게 보내기</label>
                        <p class="text-muted"><small>선택해 두면 [업데이트 확인]을 누를 때 사이트 주소, 사이트 이름, 엔진 종류와 버전, 플러그인 버전이 게시판모아 개발자(EasyAppLabs)에게 전송됩니다. 회원 정보와 글 내용은 전송되지 않으며, 전송된 정보는 공개하지 않습니다. 이 정보는 어떤 엔진과 버전에서 플러그인이 쓰이는지 파악해 호환성을 점검하고, 새 기능과 업데이트를 준비하는 데 사용합니다.</small></p>
                    </form>

                    <hr>
                    <p class="text-muted">
                        앱 연결 주소: <a href="{{ $apiUrl }}" target="_blank">{{ $apiUrl }}</a><br>
                        내려받기·설치 안내: <a href="https://github.com/easyapplabs/boardmoa-appapi-xe3" target="_blank">github.com/easyapplabs/boardmoa-appapi-xe3</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
