<?php
namespace Xpressengine\Plugins\Appapi;

/**
 * 자동 입력 방지(CAPTCHA, 기능 captcha_solve): XE3 코어의 CAPTCHA 관리자(xe.captcha)를 그대로 쓴다.
 *   - 쓰는 곳은 웹과 같다: 게시판 설정 '캡차 사용'(BoardService::checkCaptcha, 글쓰기), 회원 설정 '로그인 캡차'(AuthController::checkCaptcha).
 *     XE3 댓글에는 CAPTCHA 가 없다.
 *   - 앱이 풀 수 있는 것은 구글 reCAPTCHA v2 체크박스(코어 google 드라이버가 웹에 그리는 g-recaptcha 상자)뿐이다. 그때만 위젯 정보
 *     {type: recaptcha, site_key(웹 화면에도 나오는 공개 열쇠), theme: auto, size: normal} 를 준다. 네이버 캡차 등은 null → 앱은 웹으로 안내한다.
 *   - 앱이 푼 답(captcha_response)은 웹 양식과 같은 이름(g-recaptcha-response)으로 이번 요청에 넣고, 확인은 코어 드라이버(verify)가 한다
 *     (구글에 묻고, 사이트 주소와 같은 호스트에서 풀었는지도 본다 — 앱은 사이트 주소로 연 웹뷰에서 위젯을 띄운다).
 */
class Captcha
{
    /** 앱이 풀 위젯 정보 (못 풀면 null) */
    public static function widget()
    {
        try {
            $manager = app('xe.captcha');
            if ((string)config('captcha.driver') !== 'google' || !$manager->available()) {
                return null;
            }
            $key = (string)config('captcha.apis.google.siteKey');
            if ($key === '') {
                return null;
            }
            return ['type' => 'recaptcha', 'site_key' => $key, 'theme' => 'auto', 'size' => 'normal'];
        } catch (\Throwable $e) {
            report($e);
            return null;
        }
    }

    /** 로그인에 CAPTCHA 를 쓰는가 (웹 AuthController::checkCaptcha 와 같은 판단: 회원 설정 user.register 의 useCaptcha 가 참) */
    public static function loginRequired()
    {
        try {
            $config = app('xe.config')->get('user.register');
            return $config && $config->get('useCaptcha', false) === true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** 앱이 보낸 답을 웹 양식 이름으로 이번 요청에 넣는다. 답이 없으면 false */
    public static function applyResponse()
    {
        $answer = Api::param('captcha_response');
        if (!is_string($answer) || trim($answer) === '') {
            return false;
        }
        Api::$request->merge(['g-recaptcha-response' => trim($answer)]);
        return true;
    }

    /** 코어 드라이버로 확인 (웹과 같은 verify). 답이 없거나 틀리면 false */
    public static function verify()
    {
        if (!self::applyResponse()) {
            return false;
        }
        try {
            return app('xe.captcha')->verify() === true;
        } catch (\Throwable $e) {
            report($e);
            return false;
        }
    }

    /** 403 captcha_required + error.captcha (앱이 풀 수 있으면 위젯, 아니면 null → 앱은 웹으로 안내) */
    public static function error($message)
    {
        return new ApiError(403, 'captcha_required', $message, ['captcha' => self::widget()]);
    }
}
