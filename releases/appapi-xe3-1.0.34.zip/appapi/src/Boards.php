<?php
namespace Xpressengine\Plugins\Appapi;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use XeMenu;
use XeSkin;
use Xpressengine\Document\Models\Document;
use Xpressengine\Permission\Instance;
use Xpressengine\Plugins\Board\BoardPermissionHandler;
use Xpressengine\Plugins\Board\Models\Board;
use Xpressengine\Plugins\Comment\Models\Comment;
use Xpressengine\User\Models\User;

/**
 * 사이트·메뉴·게시판·글·댓글·첨부·페이지. 권한은 XE3 엔진(Gate·게시판 권한)이 판단한 결과를 그대로 쓴다.
 * 글·댓글·회원·파일 번호는 Store::num() 으로 정수로 바꿔 준다.
 */
class Boards
{
    const BOARD = 'board@board';
    const PAGE = 'page@page';
    /** 글·댓글 쓰기 API 를 넣기 전까지 앱의 글쓰기 버튼·댓글 입력창을 숨긴다 (앱은 서버가 준 권한이 참일 때만 보인다) */
    const WRITE_READY = true;

    // ---- 공통

    public static function absolute($url)
    {
        $url = (string)$url;
        if ($url === '' || preg_match('#^(https?:)?//#i', $url)) {
            return $url;
        }
        return rtrim(url('/'), '/') . '/' . ltrim($url, '/');
    }

    /** 본문 HTML: XE3 가 씌우는 <div class="__xe_contents_compiler"><xe-content …> 껍데기를 벗긴다 (앱은 순수 HTML 을 그린다) */
    private static function html($instanceId, $content, $isHtml)
    {
        $html = (string)compile($instanceId, $content, $isHtml);
        $html = preg_replace('#^\s*<div class="__xe_contents_compiler">\s*<xe-content[^>]*>#s', '', $html, 1, $count);
        if ($count) {
            $html = preg_replace('#</xe-content>\s*</div>\s*$#s', '', $html, 1);
        }
        // 겹친 <html><body> 껍데기·지도 도구·XE3 글 링크 (Content 참고)
        return trim(Content::clean($html));
    }

    /** ISO 8601 (사이트 시간대) */
    private static function iso($time)
    {
        return $time ? \Carbon\Carbon::parse($time)->toIso8601String() : null;
    }

    private static function perm($instanceId)
    {
        return new Instance(app(BoardPermissionHandler::class)->name($instanceId));
    }

    /** 이 회원의 게시판 권한 (엔진의 Gate) */
    public static function grant($instanceId)
    {
        static $cache = [];
        if (!isset($cache[$instanceId])) {
            $perm = self::perm($instanceId);
            $config = app('xe.board.config')->get($instanceId);
            $manager = Gate::allows(BoardPermissionHandler::ACTION_MANAGE, $perm);
            $cache[$instanceId] = [
                'list' => Gate::allows(BoardPermissionHandler::ACTION_LIST, $perm),
                'view' => Gate::allows(BoardPermissionHandler::ACTION_READ, $perm),
                // 상담 게시판은 비회원이 글을 쓸 수 없다 (웹 BoardModuleController::create·store 가 막는다)
                'write_document' => self::WRITE_READY && Gate::allows(BoardPermissionHandler::ACTION_CREATE, $perm)
                    && !($config && $config->get('useConsultation') === true && !Auth::check()),
                'write_comment' => self::WRITE_READY && $config && $config->get('comment') === true && self::canComment($instanceId),
                'manager' => $manager,
            ];
        }
        return $cache[$instanceId];
    }

    /** 댓글 쓰기 권한: 댓글 플러그인의 권한(create) */
    private static function canComment($boardInstanceId)
    {
        $handler = app('xe.plugin.comment')->getHandler();
        $commentInstanceId = $handler->getInstanceId($boardInstanceId);
        if (!$commentInstanceId) {
            return false;
        }
        return Gate::allows('create', new Instance($handler->getKeyForPerm($commentInstanceId)));
    }

    /** 주소(url)의 메뉴 항목. 없으면 null */
    private static function itemByUrl($url)
    {
        if (!is_string($url) || !preg_match('/^[A-Za-z0-9_\-]{1,80}$/', $url)) {
            throw new ApiError(400, 'invalid_mid', 'invalid mid');
        }
        return XeMenu::items()->query()->where('url', $url)->first();
    }

    private static function moduleOf($item)
    {
        $type = (string)$item->type;
        if ($type === self::BOARD) {
            return 'board';
        }
        if ($type === self::PAGE || $type === 'widgetpage@widgetpage') {
            return 'page';
        }
        return null;
    }

    /** 메뉴에서 보이고(visible), 게시판이면 목록 권한도 있는지 */
    public static function isVisible($item)
    {
        $menu = XeMenu::menus()->find($item->menu_id);
        if (!$menu || !$item->activated || Gate::denies('visible', [$item, $menu])) {
            return false;
        }
        return $item->type !== self::BOARD || self::grant($item->id)['list'];
    }

    /** 게시판 mid → [메뉴 항목, 게시판 설정]. 볼 수 없으면 없는 게시판처럼 */
    private static function boardOf($mid)
    {
        $item = self::itemByUrl($mid);
        if (!$item || $item->type !== self::BOARD) {
            throw new ApiError(404, 'board_not_found', '없는 게시판입니다.');
        }
        $config = app('xe.board.config')->get($item->id);
        if (!$config) {
            throw new ApiError(404, 'board_not_found', '없는 게시판입니다.');
        }
        return [$item, $config];
    }

    public static function title($item)
    {
        return trim(strip_tags(xe_trans($item->title)));
    }

    // ---- 사이트·메뉴

    public static function site()
    {
        $site = app('xe.site');
        $config = $site->getSiteConfig();
        $home = $site->getHomeInstanceId();
        $homeItem = $home ? XeMenu::items()->find($home) : null;
        return [
            'name' => trim(xe_trans((string)$config->get('site_title'))) ?: Api::$request->getHost(),
            // 이름이 다국어면 언어별 이름 (1.0.13~, 앱 언어 코드 => 이름). 설치 현황 서버가 추천 사이트 목록에 옮겨 쓴다
            'names' => self::siteNames((string)$config->get('site_title')),
            // 관리 화면 '개발자에게 알리기' (1.0.14~). 끄면 설치 현황 서버가 이 사이트를 목록에 넣지 않고 있던 줄도 지운다
            'share_site' => Updater::shareSite(),
            'base_url' => rtrim(url('/'), '/') . '/',
            'theme_color' => null,
            'logo_url' => null,
            'icon_url' => self::siteIcon($config),
            'home_mid' => $homeItem ? (string)$homeItem->url : null,
            'engine' => 'xe3',
            'engine_version' => defined('__XE_VERSION__') ? __XE_VERSION__ : null,
            'api_version' => Api::VERSION,
            // 이 플러그인이 할 줄 아는 것 (XE1 모듈 Menu::features 와 같은 이름, docs/API.md '기능 목록')
            // 1.0.18~: captcha_solve(reCAPTCHA v2 를 앱이 푼다), extra_vars(확장 필드), comment_vote(댓글 추천), file_upload(파일 첨부)
            // 1.0.19~: devices(로그인한 기기 보기·로그아웃)
            'features' => ['html_write', 'polls', 'resolve_path', 'guest_write', 'edit_photos', 'guest_manage', 'guest_comment', 'comment_edit', 'password_throttle', 'unlocked_comment',
                'captcha_solve', 'extra_vars', 'comment_vote', 'file_upload', 'devices'],
            'member' => Api::profile(),
        ];
    }

    /** 사이트 이름의 언어별 값 (사이트가 쓰는 언어마다 번역). 언어가 하나뿐이거나 모두 같으면 null */
    private static function siteNames($key)
    {
        if ($key === '') {
            return null;
        }
        $names = [];
        try {
            foreach ((array)xe_trans()->getLocales() as $locale) {
                $code = Api::appLangCode($locale);
                $value = trim(strip_tags((string)xe_trans($key, [], $locale)));
                if ($code !== null && $value !== '' && $value !== $key && !isset($names[$code])) {
                    $names[$code] = $value;
                }
            }
        } catch (\Throwable $e) {
            return null;
        }
        return count(array_unique($names)) > 1 ? $names : null;
    }

    /** 사이트 아이콘: 관리 화면 '사이트 설정'의 파비콘(그림, PNG 등)이 있으면 그것, 없으면 /favicon.ico */
    private static function siteIcon($config)
    {
        try {
            $id = $config->get('favicon.id');
            $image = $id ? \Xpressengine\Media\Models\Image::find($id) : null;
            if ($image) {
                return self::absolute($image->url());
            }
        } catch (\Throwable $e) {
            report($e);
        }
        return self::absolute('favicon.ico');
    }

    public static function menus()
    {
        $menus = [];
        foreach (XeMenu::menus()->query()->where('site_key', 'default')->get() as $menu) {
            $tree = XeMenu::menus()->findWith($menu->id, []);
            $items = [];
            foreach ($tree->getTree()->getTreeNodes() as $node) {
                if ($out = self::menuItem($node, $menu)) {
                    $items[] = $out;
                }
            }
            if ($items) {
                $menus[] = ['id' => (string)$menu->id, 'title' => (string)$menu->title, 'items' => $items];
            }
        }
        return ['menus' => $menus];
    }

    /** 권한 없는 항목은 빼고, 하위에 볼 것이 남은 경우에만 제목만 있는 묶음으로 남긴다 */
    private static function menuItem($item, $menu)
    {
        if (!$item->activated || Gate::denies('visible', [$item, $menu])) {
            return null;
        }
        $children = [];
        foreach ($item->getChildren() as $child) {
            if ($out = self::menuItem($child, $menu)) {
                $children[] = $out;
            }
        }
        $module = self::moduleOf($item);
        $grant = null;
        if ($module === 'board') {
            $g = self::grant($item->id);
            if (!$g['list']) {
                return $children ? ['title' => self::title($item), 'mid' => null, 'module' => null, 'grant' => null, 'url' => null, 'open_window' => false, 'children' => $children] : null;
            }
            $grant = ['view' => $g['view'], 'write_document' => $g['write_document'], 'write_comment' => $g['write_comment']];
        }
        // 주소가 '#…' 인 바로가기는 메뉴 묶음(제목만)이다 — XE1 의 '#' 메뉴처럼 주소 없이 (누르면 첫 화면이 열리지 않게)
        if (!$module && strpos((string)$item->url, '#') === 0) {
            return $children ? ['title' => self::title($item), 'mid' => null, 'module' => null, 'grant' => null, 'url' => null, 'open_window' => false, 'children' => $children] : null;
        }
        $url = $module ? self::absolute($item->url) : self::absolute((string)$item->url);
        return [
            'title' => self::title($item),
            'mid' => $module ? (string)$item->url : null,
            'module' => $module,
            'grant' => $grant,
            'url' => $url !== '' ? $url : null,
            'open_window' => $item->target === '_blank',
            'children' => $children,
        ];
    }

    /** 메뉴에 있는 게시판 중 목록을 볼 수 있는 곳 (모아 보기 기본 대상) */
    public static function visibleBoards()
    {
        $boards = [];
        foreach (XeMenu::items()->query()->where('type', self::BOARD)->where('activated', 1)->get() as $item) {
            if (self::isVisible($item)) {
                $boards[$item->id] = $item;
            }
        }
        return $boards;
    }

    // ---- 게시판

    private static function listColumns($config)
    {
        $columns = (array)($config->get('listColumns') ?: \Xpressengine\Plugins\Board\ConfigHandler::DEFAULT_SELECTED_LIST_COLUMNS);
        return ['read_count' => in_array('read_count', $columns), 'vote_count' => in_array('assent_count', $columns)];
    }

    private static function style($instanceId)
    {
        $skin = XeSkin::getAssigned(['module/board@board', $instanceId]);
        $id = $skin ? strtolower($skin->getId()) : '';
        foreach (['gallery', 'webzine', 'blog' => 'webzine', 'calendar'] as $key => $style) {
            $needle = is_int($key) ? $style : $key;
            if (strpos($id, $needle) !== false) {
                return $style;
            }
        }
        return 'list';
    }

    public static function boardInfo($item, $config)
    {
        $grant = self::grant($item->id);
        $categories = [];
        if ($config->get('category') === true && $config->get('categoryId')) {
            $walk = function ($items, $parent) use (&$walk, &$categories) {
                foreach ($items as $c) {
                    $categories[] = ['category_srl' => (int)$c->id, 'parent_srl' => (int)$parent, 'title' => trim(xe_trans($c->word)), 'document_count' => 0];
                    $walk($c->getChildren(), $c->id);
                }
            };
            $roots = \Xpressengine\Category\Models\CategoryItem::where('category_id', $config->get('categoryId'))->whereNull('parent_id')->orderBy('ordering')->get();
            $walk($roots, 0);
        }
        return [
            'mid' => (string)$item->url,
            'title' => self::title($item),
            'style' => self::style($item->id),
            'columns' => self::listColumns($config),
            'use_secret' => $config->get('secretPost') === true,
            'categories' => $categories,
            // 분류를 쓰는 게시판은 웹 글쓰기가 분류를 꼭 고르게 한다 (게시판 Validator 의 category_item_id Required)
            'category_required' => $config->get('category') === true && count($categories) > 0,
            'grant' => $grant,
            'upload' => self::uploadInfo($item->id, $grant),
            // 추가 항목(확장 필드) 정의 (1.0.18~, 기능 extra_vars): 쓰기 권한이 있을 때만 (XE·Rhymix 모듈과 같은 꼴)
            'extra_keys' => $grant['write_document'] ? Fields::keys($config) : [],
            // 비회원이 글을 쓸 수 있으면 글쓰기에서 받아야 하는 항목 (0.3.4~, 웹 글쓰기의 이름·비밀번호·메일). 회원이거나 쓸 수 없으면 null
            'guest_fields' => ($grant['write_document'] && !Auth::check()) ? ['nick_name', 'password', 'email_address'] : null,
            // 비회원이 댓글을 쓸 수 있으면 받아야 하는 항목 (0.3.5~, 웹 댓글 쓰기의 이름·메일·비밀번호 — XE3 는 메일도 필수)
            'guest_comment_fields' => ($grant['write_comment'] && !Auth::check()) ? ['nick_name', 'password', 'email_address'] : null,
            // 비회원 글·댓글을 비밀번호로 열거나 고칠 때 보내야 하는 항목 (0.3.5~): XE3 웹 확인 화면은 메일과 비밀번호를 함께 받는다
            'guest_certify_fields' => Auth::check() ? null : Guest::CERTIFY_FIELDS,
            // 글을 쓸 때 CAPTCHA 를 풀어야 하는가 (XE·Rhymix 모듈과 같은 모양, 게시판 설정 '캡차 사용'). XE3 댓글에는 CAPTCHA 가 없다.
            // 사이트 CAPTCHA 가 reCAPTCHA v2 면 앱이 풀 위젯 정보(1.0.18~, 기능 captcha_solve), 아니면 null → 앱은 웹 글쓰기(write_url)로 안내한다
            'captcha' => ['document' => Write::captchaRequired($config), 'comment' => false],
            'captcha_widget' => Write::captchaRequired($config) ? Captcha::widget() : null,
            'write_url' => self::writeUrl($item),
            // 댓글 단추의 엔진 문구 (1.0.18~, XE·Rhymix 1.0.11~ 과 같은 꼴): 웹 댓글 스킨의 답글 단추(comment::reply)·댓글 메뉴의 수정(xe::update)·삭제(xe::delete)
            'labels' => self::labels(),
        ];
    }

    /**
     * 웹 댓글 화면의 단추 글자 (이번 요청 언어). 사이트에 그 언어 번역이 없어 한국어·영어로 대신 나오는 문구는 넣지 않는다(앱 문구를 쓴다). 비어도 {}
     */
    private static function labels()
    {
        static $labels = null;
        if ($labels === null) {
            $labels = [];
            try {
                $locale = (string)app('xe.translator')->getLocale();
                foreach (['comment_reply' => 'comment::reply', 'comment_edit' => 'xe::update', 'comment_delete' => 'xe::delete'] as $name => $key) {
                    $text = trim(strip_tags((string)xe_trans($key)));
                    if ($text === '' || $text === $key) {
                        continue;
                    }
                    // 번역이 없으면 엔진은 한국어·영어로 대신 낸다 → 그 언어가 아닌데 같은 글자면 넣지 않는다
                    foreach (['ko', 'en'] as $fallback) {
                        if (stripos($locale, $fallback) !== 0 && $text === trim(strip_tags((string)xe_trans($key, [], $fallback)))) {
                            continue 2;
                        }
                    }
                    $labels[$name] = $text;
                }
            } catch (\Throwable $e) {
                report($e);
            }
        }
        return (object)$labels;
    }

    /** 웹의 글쓰기 화면 주소 */
    private static function writeUrl($item)
    {
        try {
            return self::absolute(app('xe.board.url')->get('create', [], $item->id));
        } catch (\Throwable $e) {
            return self::absolute(rtrim((string)$item->url, '/') . '/create');
        }
    }

    /**
     * 에디터 권한(올리기·내려받기)을 물을 대상. 게시판별 항목(editor.<게시판>)은 관리자가 그 게시판의 에디터 설정을
     * 저장해야 생기고, 없는 항목을 물으면 XE3 가 멈춘다(InstancePolicy). 없으면 상위 기본값 editor 를 쓴다.
     */
    public static function editorPerm($instanceId)
    {
        $key = \XeEditor::getPermKey($instanceId);
        return new Instance(app('xe.permission')->get($key) ? $key : 'editor');
    }

    /** 글쓰기에 사진을 붙일 수 있는지 (웹 에디터의 올리기 설정·권한과 같은 판단) */
    public static function uploadInfo($instanceId, $grant)
    {
        $editor = \XeEditor::get($instanceId);
        $config = $editor ? $editor->getConfig() : null;
        // 비회원도 웹 에디터와 같다 (0.3.4~): 올리기 권한(Gate upload)이 비회원을 허락하면 올린다
        $allowed = $grant['write_document'] && $config && $config->get('uploadActive')
            && Gate::allows('upload', self::editorPerm($instanceId));
        $extensions = $config ? array_map('trim', explode(',', strtolower((string)$config->get('extensions', '')))) : [];
        if ($allowed && !in_array('*', $extensions) && !in_array('jpg', $extensions) && !in_array('jpeg', $extensions)) {
            $allowed = false;
        }
        $privileged = $editor && $editor->isPrivileged();
        $mb = function ($v) use ($privileged) { return (!$privileged && (float)$v > 0) ? (int)round((float)$v * 1024 * 1024) : null; };
        // 사진이 아닌 파일 첨부 (1.0.18~, 기능 file_upload): 웹 에디터 파일 올리기(EditorController::fileUpload)와 같은 권한·허용 확장자·크기. 개수 제한은 XE3 에 없다
        $filesAllowed = $grant['write_document'] && $config && $config->get('uploadActive')
            && Gate::allows('upload', self::editorPerm($instanceId));
        $allowedExtensions = array_values(array_filter($extensions, 'strlen'));
        return [
            'allowed' => (bool)$allowed,
            'max_file_size' => $config ? $mb($config->get('fileMaxSize')) : null,
            'max_total_size' => $config ? $mb($config->get('attachMaxSize')) : null,
            'files' => [
                'allowed' => (bool)$filesAllowed,
                'max_file_size' => $config ? $mb($config->get('fileMaxSize')) : null,
                'max_count' => null,
                // '*' 이면 엔진이 확장자를 가리지 않는다
                'extensions' => (!$allowedExtensions || in_array('*', $allowedExtensions, true)) ? null : $allowedExtensions,
            ],
        ];
    }

    /** 목록 요약용 글자: 문단·줄바꿈·표 칸 경계에 빈칸을 넣고 태그를 벗긴 뒤 빈칸을 하나로 줄인다 */
    public static function plainText($html)
    {
        $html = preg_replace('#<(script|style)\b[^>]*>.*?</\1\s*>#is', ' ', (string)$html);
        $html = preg_replace('#<(?:br|hr)\b[^>]*>|</?(?:p|div|li|ul|ol|h[1-6]|tr|td|th|table|blockquote|pre|section|article|header|footer|figure|figcaption|dd|dt|dl)\b[^>]*>#i', ' ', $html);
        $text = html_entity_decode(strip_tags($html), ENT_QUOTES, 'UTF-8');
        return trim(preg_replace('/[\s\x{00A0}]+/u', ' ', $text));
    }

    /**
     * 목록 그림: 웹 갤러리·웹진 스킨(GallerySkin::bindGalleryThumb)과 같은 순서.
     * 정해 둔 대표 그림(board_gallery_thumbs) → 첨부 그림 → 본문의 첫 그림. 읽을 수 있는 글에만 부른다.
     */
    public static function thumbnail(Board $doc)
    {
        $thumb = $doc->thumb ?? null;
        if ($thumb) {
            $path = (string)$thumb->board_thumbnail_path ?: (string)$thumb->board_thumbnail_external_path;
            if ($path !== '') {
                return self::absolute($path);
            }
        }
        if ((int)($doc->boardData->file_count ?? 0) > 0) {
            try {
                $media = app('xe.media');
                foreach (\XeStorage::fetchByFileable($doc->id) as $file) {
                    if ($media->is($file) !== true) {
                        continue;
                    }
                    $image = (new \Xpressengine\Media\Repositories\ImageRepository())->getThumbnail(
                        $media->make($file), \Xpressengine\Plugins\Board\Components\Modules\BoardModule::THUMBNAIL_TYPE, 'L');
                    if ($image !== null) {
                        return self::absolute($image->url());
                    }
                }
            } catch (\Throwable $e) {
                // 썸네일을 못 만들면 본문 그림으로 넘어간다
            }
        }
        return self::contentImage((string)$doc->content);
    }

    /** 본문의 첫 그림 (data: 주소·이모티콘·아이콘·아주 작은 그림은 건너뛴다) */
    public static function contentImage($html)
    {
        if (stripos($html, '<img') === false || !preg_match_all('#<img\b[^>]*>#i', $html, $tags)) {
            return null;
        }
        foreach ($tags[0] as $tag) {
            $src = '';
            foreach (['src', 'data-src', 'data-original'] as $attr) {
                if (preg_match('#\s' . $attr . '\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))#i', $tag, $m)) {
                    $v = trim(html_entity_decode($m[1] . ($m[2] ?? '') . ($m[3] ?? ''), ENT_QUOTES, 'UTF-8'));
                    if ($v !== '' && stripos($v, 'data:') !== 0) {
                        $src = $v;
                        break;
                    }
                }
            }
            if ($src === '' || preg_match('#^(?!https?:|//)[a-z][a-z0-9+.-]*:#i', $src)) {
                continue;
            }
            if (preg_match('#emoticon|/icons?/|/emoji|/smiley|spacer\.gif|blank\.gif#i', $src)) {
                continue;
            }
            $small = false;
            foreach (['width', 'height'] as $attr) {
                if (preg_match('#\s' . $attr . '\s*=\s*["\']?\s*(\d+)\s*(px)?["\'\s>/]#i', $tag, $m) && (int)$m[1] > 0 && (int)$m[1] < 50) {
                    $small = true;
                }
                if (preg_match('#style\s*=\s*["\'][^"\']*\b' . $attr . '\s*:\s*(\d+)px#i', $tag, $m) && (int)$m[1] > 0 && (int)$m[1] < 50) {
                    $small = true;
                }
            }
            if ($small) {
                continue;
            }
            if (strpos($src, '//') === 0) {
                return (request()->secure() ? 'https:' : 'http:') . $src;
            }
            return self::absolute($src);
        }
        return null;
    }

    /** 앱의 문서요약 */
    public static function summary(Board $doc, $config, $canView)
    {
        $user = Auth::user();
        $secret = (int)$doc->display === Document::DISPLAY_SECRET;
        $mine = Auth::check() && $doc->user_id && $doc->user_id === $user->getId();
        $accessible = $canView && (!$secret || $mine || self::grant($doc->instance_id)['manager']);
        $columns = self::listColumns($config);
        $plain = $accessible ? self::plainText((string)$doc->content ?: (string)$doc->pure_content) : '';
        $anonymous = $doc->user_type === Document::USER_TYPE_ANONYMITY || $doc->user_type === Document::USER_TYPE_GUEST;
        return [
            'document_srl' => Store::num($doc->id),
            'title' => (string)$doc->title,
            'author' => (string)$doc->writer,
            'author_image' => (!$anonymous && $doc->user) ? Api::profileImage($doc->user) : null,
            'author_srl' => (!$anonymous && $doc->user_id) ? Store::num($doc->user_id) : 0,
            'is_mine' => (bool)$mine,
            'regdate' => self::iso($doc->created_at),
            'last_update' => self::iso($doc->updated_at),
            'category_srl' => (int)($doc->boardCategory->item_id ?? 0),
            'comment_count' => (int)$doc->comment_count,
            'read_count' => $columns['read_count'] ? (int)$doc->read_count : null,
            'vote_count' => $columns['vote_count'] ? (int)$doc->assent_count : null,
            'is_notice' => (int)$doc->status === Document::STATUS_NOTICE,
            'is_secret' => $secret,
            'has_files' => (int)($doc->boardData->file_count ?? 0) > 0,
            'thumbnail' => $accessible ? self::thumbnail($doc) : null,
            'summary' => $accessible ? mb_substr($plain, 0, 120) : '',
        ];
    }

    /** 게시판 목록용 요청 (웹 목록과 같은 조건: 페이지·분류·검색) */
    private static function listRequest()
    {
        $r = Api::$request;
        $q = ['page' => max(1, Api::intParam('page', 1))];
        if ($c = Api::intParam('category')) {
            $q['category_item_id'] = $c;
        }
        $keyword = trim((string)Api::param('search_keyword', ''));
        if ($keyword !== '') {
            $target = (string)Api::param('search_target', 'title_content');
            $map = ['title' => 'title', 'content' => 'content', 'title_content' => 'title_pure_content', 'nick_name' => 'writer', 'user_id' => 'writer'];
            $q[$map[$target] ?? 'title_pure_content'] = $keyword;
        }
        $list = Request::create($r->url(), 'GET', $q);
        $list->setUserResolver(function () { return Auth::user(); });
        \Illuminate\Pagination\Paginator::currentPageResolver(function () use ($q) { return $q['page']; });
        return $list;
    }

    public static function board()
    {
        list($item, $config) = self::boardOf(Api::param('mid'));
        if (!self::isVisible($item)) {
            // 목록 권한이 없으면 웹처럼 막는다 (비회원이면 로그인을 권하도록 401)
            throw new ApiError(Auth::check() ? 403 : 401, 'not_permitted', Api::message('not_permitted'));
        }
        $service = app(\Xpressengine\Plugins\Board\Services\BoardService::class);
        $request = self::listRequest();
        $canView = self::grant($item->id)['view'];
        $notices = [];
        if ($request->get('page', 1) == 1) {
            foreach ($service->getNoticeItems($request, $config, Auth::user()->getId()) as $doc) {
                $notices[] = self::summary($doc, $config, $canView);
            }
        }
        $paginate = $service->getItems($request, $config);
        $documents = [];
        foreach ($paginate as $doc) {
            $documents[] = self::summary($doc, $config, $canView);
        }
        return [
            'board' => self::boardInfo($item, $config),
            'notices' => $notices,
            'documents' => $documents,
            'page' => (int)$paginate->currentPage(),
            'total_pages' => max(1, (int)$paginate->lastPage()),
            'total_count' => (int)$paginate->total(),
        ];
    }

    public static function feed()
    {
        $boards = self::visibleBoards();
        $mids = array_filter(explode(',', (string)Api::param('mids', '')));
        if ($mids) {
            $boards = array_filter($boards, function ($item) use ($mids) { return in_array($item->url, $mids, true); });
        }
        $count = min(50, max(5, Api::intParam('list_count', 20)));
        $page = max(1, Api::intParam('page', 1));
        if (!$boards) {
            return ['documents' => [], 'page' => 1, 'total_pages' => 1];
        }
        // 상담 게시판은 웹 목록처럼 자기 글만 (관리자는 모두, 비회원은 없음 — BoardService::getItems·위젯과 같다)
        $open = [];
        $ownOnly = [];
        foreach (array_keys($boards) as $instanceId) {
            $config = app('xe.board.config')->get($instanceId);
            if ($config && $config->get('useConsultation') === true && !self::grant($instanceId)['manager']) {
                if (Auth::check()) {
                    $ownOnly[] = $instanceId;
                }
            } else {
                $open[] = $instanceId;
            }
        }
        if (!$open && !$ownOnly) {
            return ['documents' => [], 'page' => 1, 'total_pages' => 1];
        }
        $query = Board::where(function ($q) use ($open, $ownOnly) {
            if ($open) {
                $q->whereIn('instance_id', $open);
            }
            if ($ownOnly) {
                $q->orWhere(function ($q) use ($ownOnly) {
                    $q->whereIn('instance_id', $ownOnly)->where('user_id', Auth::id());
                });
            }
        })
            ->where('status', '!=', Document::STATUS_TRASH)
            ->where('approved', Document::APPROVED_APPROVED)
            ->where('published', Document::PUBLISHED_PUBLISHED)
            ->where('display', '!=', Document::DISPLAY_HIDDEN)
            ->orderBy('head', 'desc');
        $paginate = $query->paginate($count, ['*'], 'page', $page);
        $documents = [];
        foreach ($paginate as $doc) {
            $item = $boards[$doc->instance_id];
            $config = app('xe.board.config')->get($doc->instance_id);
            $summary = self::summary($doc, $config, self::grant($doc->instance_id)['view']);
            $summary['mid'] = (string)$item->url;
            $summary['board_title'] = self::title($item);
            $documents[] = $summary;
        }
        return ['documents' => $documents, 'page' => $page, 'total_pages' => max(1, (int)$paginate->lastPage())];
    }

    /**
     * 글 하나 + 읽기 권한 확인 (웹의 BoardModuleController::show 와 같은 판단).
     * $locked 를 넘기면(document): 비회원 비밀글을 비회원이 열 때 웹은 비밀번호 확인 화면으로 보낸다 → 막지 않고 $locked = true 로 글을 준다(본문은 주지 않는다)
     */
    private static function readable($item, $config, $documentSrl, &$locked = null)
    {
        $wantsLocked = func_num_args() > 3;
        $locked = false;
        $uuid = Store::uuid($documentSrl);
        $service = app(\Xpressengine\Plugins\Board\Services\BoardService::class);
        $user = Auth::user();
        $manager = self::grant($item->id)['manager'];
        try {
            $doc = $uuid ? $service->getItem($uuid, $user, $config, $manager) : null;
        } catch (\Xpressengine\Plugins\Board\Exceptions\NotFoundDocumentException $e) {
            $doc = null;
        } catch (\Xpressengine\Plugins\Board\Exceptions\GuestWrittenSecretDocumentException $e) {
            // 엔진은 비회원 비밀글이면 휴지통·승인 확인 전에 이 예외를 던진다(웹은 비밀번호 화면으로 보낸다).
            // 비밀글은 휴지통에 가도 비밀글로 남으므로, 휴지통·승인 대기·발행 전 글은 여기서 없는 글로 (관리자는 이 길로 오지 않는다)
            $doc = Board::division($config->get('boardId'))->find($uuid);
            if ($doc && !self::listable($doc, true)) {
                $doc = null;
            } elseif ($doc && !$wantsLocked) {
                throw new ApiError(403, 'not_permitted', '비밀글입니다.');
            }
            $locked = true;
        }
        if (!$doc || $doc->instance_id !== $item->id) {
            throw new ApiError(404, 'document_not_found', '없는 글입니다.');
        }
        if ($locked) {
            // 제목은 목록에 보이는 만큼만: 목록을 볼 수 없거나 상담 게시판(자기 글만 보인다)이면 막는다
            if (!self::grant($item->id)['list'] || $config->get('useConsultation') === true) {
                throw new ApiError(Auth::check() ? 403 : 401, 'not_permitted', Api::message('not_permitted'));
            }
            return [$doc, false];
        }
        $own = self::owns($doc, $manager);
        if (!$own && !self::grant($item->id)['view']) {
            throw new ApiError(Auth::check() ? 403 : 401, 'not_permitted', Api::message('not_permitted'));
        }
        if ($config->get('useConsultation') === true && !$own) {
            throw new ApiError(403, 'not_permitted', Api::message('not_permitted'));
        }
        return [$doc, $own];
    }

    /**
     * 작성자 본인이거나 관리자인가. 엔진 hasItemPerm 은 회원 번호를 느슨하게(==) 견줘, 비회원 글(user_id '')이면 비회원(null) 누구나 본인이 된다
     * (상담 게시판의 남의 비회원 글, 읽기 권한이 없는 비회원에게 비회원 글이 열린다). 그래서 회원은 같은 번호일 때만,
     * 비회원은 그 글의 메일·비밀번호를 이번 요청에서 확인했을 때만(Guest::certifyDocument → 엔진 identified) 본인으로 본다
     */
    public static function owns(Board $doc, $manager)
    {
        if ($manager) {
            return true;
        }
        if (Auth::check()) {
            return (string)$doc->user_id !== '' && (string)$doc->user_id === (string)Auth::id();
        }
        return $doc->isGuest() && (string)$doc->certify_key !== '' && app('xe.board.identify')->identified($doc) === true;
    }

    /**
     * 목록에 나오는 상태인가 (휴지통이 아니고 발행됐고 숨김이 아님, $approved 면 승인된 글만 — Board::scopeVisible 과 같은 조건).
     * 엔진 getItem 이 따지지 않는 길(비회원 비밀글)에서 쓴다
     */
    public static function listable(Board $doc, $approved)
    {
        if (in_array((int)$doc->status, [Document::STATUS_TRASH, Document::STATUS_TRASH_NOTICE], true)
            || (int)$doc->published !== Document::PUBLISHED_PUBLISHED || (int)$doc->display === Document::DISPLAY_HIDDEN) {
            return false;
        }
        return !$approved || (int)$doc->approved === Document::APPROVED_APPROVED;
    }

    public static function document()
    {
        list($item, $config) = self::boardOf(Api::param('mid'));
        $documentSrl = Api::intParam('document_srl');
        if (!$documentSrl) {
            throw new ApiError(400, 'missing_document_srl', 'document_srl is required');
        }
        // 비회원 글 비밀번호 (0.3.5~, 기능 guest_manage): 웹 비회원 확인(메일·비밀번호)과 같은 확인으로 이번 요청에서만 인증된 것으로 본다
        $password = Guest::password();
        if ($password !== null) {
            $uuid = Store::uuid($documentSrl);
            $raw = $uuid ? Board::division($config->get('boardId'))->find($uuid) : null;
            // 휴지통·발행 전 글은 비밀번호로도 열지 않는다 (승인 대기는 글쓴이가 볼 수 있다 — 엔진 getItem 과 같다)
            $manager = self::grant($item->id)['manager'];
            if (!$raw || $raw->instance_id !== $item->id || (!$manager && !self::listable($raw, false))) {
                throw new ApiError(404, 'document_not_found', '없는 글입니다.');
            }
            Guest::certifyDocument($raw, $password);
        }
        list($doc, $own) = self::readable($item, $config, $documentSrl, $locked);
        if ($locked) {
            return self::lockedDocument($doc, $item, $config);
        }
        if ((int)$doc->display === Board::DISPLAY_VISIBLE) {
            // 조회수 + 포인트 플러그인의 읽기 판단 (웹 게시판 화면과 같게, 모자라면 막는다)
            Points::read($doc, Auth::user());
        }
        $grant = self::grant($item->id);
        $data = self::summary($doc, $config, true);
        $data['content_html'] = self::html($doc->instance_id, $doc->content, $doc->format === Board::FORMAT_HTML);
        // with_polls=1(새 앱): 글 속 설문을 자리표시로 두고 데이터로 준다. 없으면 예전과 똑같이 엔진이 그린 설문 화면 그대로
        $pollIds = [];
        if (Api::param('with_polls')) {
            $data['content_html'] = Polls::replaceRendered($data['content_html'], Polls::idsIn($doc->content), $pollIds);
        }
        // 태그 (1.0.18~): 웹 글 보기 아래 태그 목록처럼 본문 끝에 글자로 (게시판 '태그 사용'일 때)
        $data['content_html'] .= Fields::tagsHtml($doc, $config);
        $data['files'] = self::files($doc, $item);
        // 추가 항목(확장 필드) 값 (1.0.18~): 웹 글 보기와 같은 항목 스킨으로 그린 글자
        $data['extra_vars'] = Fields::display($doc, $config);
        $data['permanent_url'] = self::absolute(app('xe.board.url')->getShow($doc));
        $data['can_comment'] = $grant['write_comment'] && (int)($doc->boardData->allow_comment ?? 1) === 1;
        // 비밀번호로 연 비회원 비밀글: 댓글을 쓸 때 연 메일·비밀번호를 document_email·document_password 로 같이 보낸다 (기능 unlocked_comment)
        $data['comment_document_password'] = $password !== null && $data['can_comment'] && (int)$doc->display === Document::DISPLAY_SECRET;
        // 작성자 본인이거나 관리 권한 (고치기·지우기 요청도 같은 판단으로 막는다)
        $data['can_edit'] = Auth::check() && $own;
        $data['can_delete'] = Auth::check() && $own;
        // 비회원 글: 로그인하지 않은 사람은 웹처럼 메일·비밀번호를 넣으면 고치고 지울 수 있다 (0.3.5~). 회원은 비회원 글을 고칠 수 없다(웹 hasItemPerm)
        $data['password_edit'] = !$data['can_edit'] && !Auth::check() && $doc->isGuest() && (string)$doc->certify_key !== '';
        $data['password_view'] = false;
        $data['board'] = self::boardInfo($item, $config);
        $data['actions'] = Write::actions($doc, $item, $config);
        $data['comments'] = self::commentPage($doc);
        if (Api::param('with_polls')) {
            $data['polls'] = Polls::infos($pollIds);
        }
        return $data;
    }

    /** 비밀번호를 넣어야 열리는 비회원 비밀글: 목록에 보이는 만큼만(제목·이름 등), 본문·첨부·댓글은 주지 않는다 */
    private static function lockedDocument(Board $doc, $item, $config)
    {
        $data = self::summary($doc, $config, false);
        $data['content_html'] = null;
        $data['files'] = [];
        $data['extra_vars'] = [];
        $data['permanent_url'] = self::absolute(app('xe.board.url')->getShow($doc));
        $data['can_comment'] = false;
        $data['can_edit'] = false;
        $data['can_delete'] = false;
        $data['password_edit'] = (string)$doc->certify_key !== '';
        $data['password_view'] = (string)$doc->certify_key !== '';
        $data['board'] = self::boardInfo($item, $config);
        $data['actions'] = Write::actions($doc, $item, $config);
        $data['comments'] = ['items' => [], 'page' => 1, 'total_pages' => 1, 'total_count' => 0];
        return $data;
    }

    /**
     * 글 아래 기능(추천·추천인·스크랩·신고)용: document 와 같은 판단으로 읽을 수 있는 글 (엔진 getItem — 비밀글·휴지통·미승인·상담 게시판).
     * 로그인하지 않았고 비밀번호(password·email_address)를 보냈으면 document 처럼 이번 요청에서만 비회원 글을 연다
     */
    public static function readableDocument($item, $config, $documentSrl)
    {
        $password = Guest::password();
        if ($password !== null) {
            $uuid = Store::uuid($documentSrl);
            $raw = $uuid ? Board::division($config->get('boardId'))->find($uuid) : null;
            if (!$raw || $raw->instance_id !== $item->id || (!self::grant($item->id)['manager'] && !self::listable($raw, false))) {
                throw new ApiError(404, 'document_not_found', '없는 글입니다.');
            }
            Guest::certifyDocument($raw, $password);
        }
        list($doc) = self::readable($item, $config, $documentSrl);
        // 엔진 getItem 은 휴지통 글을 막지 않는다(관리자가 아니어도 통과) → 목록에 나오는 상태가 아니면 없는 글로 (관리자는 그대로)
        if (!self::grant($item->id)['manager'] && !self::listable($doc, false)) {
            throw new ApiError(404, 'document_not_found', '없는 글입니다.');
        }
        return $doc;
    }

    /** 설문 투표: 글을 읽을 수 있어야 한다 (document 와 같은 판단). [글, 웹 본문에 투표 화면으로 나오는 설문 번호] */
    public static function readableForPoll($mid, $documentSrl)
    {
        list($item, $config) = self::boardOf($mid);
        list($doc) = self::readable($item, $config, $documentSrl);
        Polls::replaceRendered(self::html($doc->instance_id, $doc->content, $doc->format === Board::FORMAT_HTML), Polls::idsIn($doc->content), $rendered);
        return [$doc, $rendered];
    }

    public static function comments()
    {
        list($item, $config) = self::boardOf(Api::param('mid'));
        list($doc) = self::readable($item, $config, Api::intParam('document_srl'));
        return self::commentPage($doc);
    }

    /** 댓글: 웹처럼 head(최신 묶음)·reply(답글 순서) 순서, 20개씩 */
    private static function commentPage(Board $doc)
    {
        $handler = app('xe.plugin.comment')->getHandler();
        $instanceId = $handler->getInstanceId($doc->instance_id);
        $empty = ['items' => [], 'page' => 1, 'total_pages' => 1, 'total_count' => 0];
        if (!$instanceId) {
            return $empty;
        }
        $config = $handler->getConfig($instanceId);
        $direction = $config->get('reverse') === true ? 'asc' : 'desc';
        $query = $handler->createModel($instanceId)->newQuery()
            ->whereHas('target', function ($q) use ($doc) {
                $q->where('target_id', $doc->id)->where('target_type', Board::class);
            })
            ->where('display', '!=', Comment::DISPLAY_HIDDEN)
            ->where('status', '!=', Comment::STATUS_TRASH)
            ->orderBy('head', $direction)->orderBy('reply', 'asc');
        $perPage = 20;
        $page = max(1, Api::intParam('cpage', 1));
        $paginate = $query->paginate($perPage, ['*'], 'cpage', $page);
        $user = Auth::user();
        $manager = Gate::allows('manage', new Instance($handler->getKeyForPerm($instanceId)));
        $voteConfig = self::commentVoteConfig($config);
        $items = [];
        foreach ($paginate as $c) {
            $mine = Auth::check() && $c->user_id && $c->user_id === $user->getId();
            $secret = (int)$c->display === Comment::DISPLAY_SECRET;
            $accessible = !$secret || $mine || $manager || (Auth::check() && $doc->user_id === $user->getId());
            $anonymous = $c->user_type === Document::USER_TYPE_ANONYMITY || $c->user_type === Document::USER_TYPE_GUEST;
            $canEdit = Auth::check() && $accessible && Gate::allows('update', $c);
            $items[] = [
                'comment_srl' => Store::num($c->id),
                'parent_srl' => $c->parent_id && $c->parent_id !== $doc->id ? Store::num($c->parent_id) : 0,
                'depth' => (int)floor(strlen((string)$c->reply) / Document::getReplyCharLen()),
                'author' => (string)$c->writer,
                'author_image' => (!$anonymous && $c->user) ? Api::profileImage($c->user) : null,
                'author_srl' => (!$anonymous && $c->user_id) ? Store::num($c->user_id) : 0,
                'is_mine' => (bool)$mine,
                'regdate' => self::iso($c->created_at),
                'is_secret' => $secret,
                // 관리자가 거절한 댓글은 웹(Comment::getContent)처럼 원문 대신 '삭제된 댓글' 문구
                'content_html' => $accessible ? self::html($instanceId, self::commentContent($c), $c->format === Comment::FORMAT_HTML) : null,
                'vote_count' => (int)$c->assent_count,
                'can_delete' => Auth::check() && Gate::allows('delete', $c),
                // 고치기 (0.3.5~, 기능 comment_edit): 웹과 같은 댓글 정책(CommentPolicy update)
                'can_edit' => $canEdit,
                // 비회원 댓글: 로그인하지 않은 사람은 웹처럼 메일·비밀번호를 넣으면 고치고 지울 수 있다 (0.3.5~)
                'password_edit' => !$canEdit && !Auth::check() && $c->getAuthor() instanceof \Xpressengine\User\Models\Guest && (string)$c->certify_key !== '',
                'files' => [],
                // 댓글 추천 (1.0.18~, 기능 comment_vote): 웹 댓글 스킨이 추천·비추천 단추를 보일 때만, 내용을 볼 수 있는 댓글에만
                'vote' => $accessible ? self::commentVote($c, $voteConfig) : null,
            ];
        }
        return [
            'items' => $items,
            'page' => (int)$paginate->currentPage(),
            'total_pages' => max(1, (int)$paginate->lastPage()),
            'total_count' => (int)$paginate->total(),
        ];
    }

    /**
     * 웹에 보이는 댓글 본문 (댓글 모델 getContent 와 같은 판단: 휴지통·관리자 거절이면 엔진 문구 comment::removeContent).
     * getContent 는 값을 엄격히(===) 견줘 DB 가 글자로 주면 거절을 놓친다 → 정수로 견준다
     */
    public static function commentContent(Comment $c)
    {
        if ((int)$c->status === Comment::STATUS_TRASH || (int)$c->approved === Comment::APPROVED_REJECTED) {
            return '<p>' . e((string)xe_trans('comment::removeContent')) . '</p>';
        }
        return (string)$c->content;
    }

    /** 댓글 설정의 추천·비추천 사용 (웹 댓글 스킨이 단추를 보이는 조건: useAssent·useDissent 가 참) */
    public static function commentVoteConfig($commentConfig)
    {
        return ['assent' => $commentConfig->get('useAssent') === true, 'dissent' => $commentConfig->get('useDissent') === true];
    }

    /**
     * 댓글 추천 상태 {up, down, my_vote, can_cancel} (docs/API.md '댓글 추천'). 둘 다 안 쓰면 null.
     * my_vote 는 웹과 같은 기록(댓글 핸들러 bindUserVote: 이 회원의 추천 기록)으로, 비회원은 0 (XE3 웹은 비회원 추천을 받지 않는다).
     * 같은 단추를 다시 누르면 취소된다(웹 voteOff) → can_cancel 참
     */
    public static function commentVote(Comment $comment, array $voteConfig)
    {
        if (!$voteConfig['assent'] && !$voteConfig['dissent']) {
            return null;
        }
        $my = 0;
        if (Auth::check()) {
            app('xe.plugin.comment')->getHandler()->bindUserVote($comment);
            $my = $comment->isAssented() ? 1 : ($comment->isDissented() ? -1 : 0);
        }
        return [
            'up' => ['enabled' => $voteConfig['assent'], 'count' => (int)$comment->assent_count],
            'down' => ['enabled' => $voteConfig['dissent'], 'count' => (int)$comment->dissent_count],
            'my_vote' => $my,
            'can_cancel' => true,
        ];
    }

    /** 댓글 추천: 그 댓글의 글을 읽을 수 있고(document 와 같은 판단) 댓글 내용도 볼 수 있어야 한다 (비밀 댓글은 글쓴이·댓글 쓴이·관리자) */
    public static function readableComment($item, $config, Comment $comment)
    {
        $target = $comment->target;
        if (!$target || $target->target_type !== Board::class) {
            throw new ApiError(404, 'comment_not_found', '없는 댓글입니다.');
        }
        list($doc) = self::readable($item, $config, Store::num($target->target_id));
        $handler = app('xe.plugin.comment')->getHandler();
        $manager = Gate::allows('manage', new Instance($handler->getKeyForPerm($comment->instance_id)));
        $userId = Auth::id();
        $mine = Auth::check() && $comment->user_id && $comment->user_id === $userId;
        $accessible = (int)$comment->display !== Comment::DISPLAY_SECRET || $mine || $manager || (Auth::check() && $doc->user_id === $userId);
        if ((int)$comment->display === Comment::DISPLAY_HIDDEN || (int)$comment->status === Comment::STATUS_TRASH) {
            throw new ApiError(404, 'comment_not_found', '없는 댓글입니다.');
        }
        if (!$accessible) {
            throw new ApiError(403, 'not_permitted', Api::message('not_permitted'));
        }
        return $doc;
    }

    private static function files(Board $doc, $item)
    {
        $out = [];
        foreach ($doc->files as $file) {
            $image = strpos((string)$file->mime, 'image/') === 0;
            $out[] = [
                'file_srl' => Store::num($file->id),
                'name' => (string)$file->clientname,
                'size' => (int)$file->size,
                'is_image' => $image,
                'image_url' => $image ? self::absolute($file->url()) : null,
                'download' => ['r' => 'file', 'file_srl' => Store::num($file->id), 'mid' => (string)$item->url, 'document_srl' => Store::num($doc->id)],
            ];
        }
        return $out;
    }

    /** 첨부 내려받기: 글을 읽을 수 있고 에디터의 다운로드 권한이 있을 때 (웹 EditorController::download 와 같은 판단) */
    public static function file()
    {
        list($item, $config) = self::boardOf(Api::param('mid'));
        list($doc) = self::readable($item, $config, Api::intParam('document_srl'));
        $uuid = Store::uuid(Api::intParam('file_srl'));
        $file = $uuid ? $doc->files->firstWhere('id', $uuid) : null;
        if (!$file) {
            throw new ApiError(404, 'not_found', Api::message('not_found'));
        }
        $editor = app('xe.editor');
        if (Gate::denies('download', self::editorPerm($item->id))) {
            throw new ApiError(Auth::check() ? 403 : 401, 'not_permitted', '파일을 내려받을 권한이 없습니다.');
        }
        // 포인트 플러그인의 내려받기 판단 (웹과 같게, 사진 제외)
        $counted = Points::beforeDownload($item->id, $file);
        $response = \XeStorage::download($file);
        if ($counted) {
            Points::downloaded($item->id, $file);
        }
        return $response;
    }

    // ---- 페이지·링크 풀이

    public static function page()
    {
        $item = self::itemByUrl(Api::param('mid'));
        if (!$item || self::moduleOf($item) !== 'page') {
            throw new ApiError(400, 'not_page', 'not a page');
        }
        if (!self::isVisible($item)) {
            throw new ApiError(404, 'not_found', Api::message('not_found'));
        }
        $html = '';
        $type = 'outside';
        if ($item->type === self::PAGE) {
            $handler = app('xe.page.handler');
            $config = $handler->getPageConfig($item->id);
            $uids = (array)$config->get('pcUids');
            $locale = app('xe.translator')->getLocale();
            $uid = $uids[$locale] ?? reset($uids);
            $doc = $uid ? app('xe.document')->get($uid, $item->id) : null;
            $html = $doc ? self::html($item->id, $doc->content, true) : '';
            $type = 'article';
        } elseif ($item->type === 'widgetpage@widgetpage') {
            // 위젯 페이지(홈): 이 회원이 볼 수 있는 것만 직접 그린다. 그릴 위젯이 없으면 예전처럼 outside(웹 화면으로 보기)
            $html = Widgets::page($item);
            $type = $html !== '' ? 'widget' : 'outside';
        }
        return [
            'mid' => (string)$item->url,
            'title' => self::title($item),
            'page_type' => $type,
            'content_html' => $html,
            'web_url' => self::absolute($item->url),
        ];
    }

    /**
     * 링크 풀이. path(또는 url)를 주면(새 앱) XE3 글 주소 꼴(/mid/<슬러그>, /mid/show/<uuid>, /mid/num/<번호>, /archives/<슬러그>)도
     * mid·document_srl 로 바꾼다. path 가 없으면 예전과 같다.
     */
    public static function resolve()
    {
        $mid = (string)Api::param('mid', '');
        $documentSrl = Api::intParam('document_srl');
        $path = (string)(Api::param('path', '') ?: Api::param('url', ''));
        if ($path !== '' && !$documentSrl) {
            $found = preg_match('#^(https?:)?//#i', $path) ? Content::documentOfUrl($path) : Content::documentOfPath('/' . ltrim(preg_replace('/[?#].*$/s', '', $path), '/'));
            if ($found) {
                $mid = $found['mid'];
                $documentSrl = $found['document_srl'];
            } elseif ($mid === '') {
                throw new ApiError(404, 'not_found', Api::message('not_found'));
            }
        }
        $item = $mid !== '' ? self::itemByUrl($mid) : null;
        if (!$item && $documentSrl && ($uuid = Store::uuid($documentSrl))) {
            $doc = Board::find($uuid);
            $item = $doc ? XeMenu::items()->find($doc->instance_id) : null;
        }
        if (!$item || !self::isVisible($item)) {
            throw new ApiError(404, 'not_found', Api::message('not_found'));
        }
        return ['mid' => (string)$item->url, 'module' => self::moduleOf($item), 'title' => self::title($item), 'document_srl' => $documentSrl ?: null];
    }
}
