<?php
namespace Xpressengine\Plugins\Appapi;

use XeDB;
use Xpressengine\Plugins\Board\Models\Board;

/**
 * 게시판 추가 항목(XE3 확장 필드 DynamicField, 기능 extra_vars)과 태그.
 *
 * 정의는 엔진의 DynamicField 설정(게시판의 documentGroup)을 그대로 읽고, 앱에는 XE·Rhymix 모듈의 extra_keys 와 같은 꼴로 준다
 * (idx 는 그 게시판 항목 순서 1부터, 쓰지 않는(use 끔) 항목은 웹 글쓰기처럼 빼되 번호는 그대로 센다).
 * 값은 엔진이 웹 글쓰기 양식에서 받는 이름(<항목 id>_<칸>)으로 바꿔 넘기고, 검사는 웹과 같은 항목 규칙(필수·숫자·메일 등, 타입의 getRules)으로 한다.
 * 저장: 글쓰기는 BoardService::store(웹과 같은 길, DynamicField 프록시가 넣는다). 고치기는 엔진 게시판 핸들러가 글에 붙어 오지 않은
 * 항목 값을 넘기지 않아(XE3 는 정렬·검색을 켠 항목만 글과 함께 읽는다 — 웹 고치기도 그 밖의 항목은 바뀌지 않는다) 같은 DynamicField 프록시로 따로 고친다.
 * 앱이 그릴 수 없는 형식(다른 플러그인의 항목 등)은 editable=false 로 알리고 받지 않는다.
 */
class Fields
{
    /** 엔진 형식(코어 확장 필드) → 앱이 그리는 형식 */
    const TYPES = [
        'fieldType/xpressengine@Text' => 'text',
        'fieldType/xpressengine@Textarea' => 'textarea',
        'fieldType/xpressengine@Number' => 'number',
        'fieldType/xpressengine@Email' => 'email_address',
        'fieldType/xpressengine@Url' => 'url',
        'fieldType/xpressengine@CellPhoneNumber' => 'tel',
        'fieldType/xpressengine@Boolean' => 'radio',
        'fieldType/xpressengine@Category' => 'select',
        'fieldType/xpressengine@Address' => 'kr_zip',
    ];

    /** 주소 항목의 칸 (앱은 이 이름으로 우편번호 찾기 결과를 채운다: XE·Rhymix 모듈과 같은 한국어 이름) */
    const ZIP_PARTS = ['우편번호', '주소', '상세 주소'];

    // ---- 정의

    /** 이 게시판의 쓰는 항목 [idx => [설정, 타입]] */
    private static function definitions($boardConfig)
    {
        static $cache = [];
        $group = (string)$boardConfig->get('documentGroup');
        if (!isset($cache[$group])) {
            $cache[$group] = [];
            if ($group === '') {
                return [];
            }
            try {
                $handler = app('xe.dynamicField');
                $idx = 0;
                foreach ($handler->getConfigHandler()->gets($group) as $config) {
                    $idx++;
                    if ($config->get('use') !== true) {
                        continue; // 웹 글쓰기·보기도 쓰지 않는 항목은 그리지 않는다
                    }
                    $type = $handler->getByConfig($config);
                    if ($type) {
                        $cache[$group][$idx] = [$config, $type];
                    }
                }
            } catch (\Throwable $e) {
                report($e);
            }
        }
        return $cache[$group];
    }

    /** 앱 형식 (그릴 수 없으면 null). 글자 항목의 메일·주소 모양(스킨)과 분류의 동그라미 모양도 따른다 */
    private static function appType($config)
    {
        $type = self::TYPES[(string)$config->get('typeId')] ?? null;
        $skin = (string)$config->get('skinId');
        if ($type === 'text' && substr($skin, -9) === 'TextEmail') {
            return 'email_address';
        }
        if ($type === 'text' && substr($skin, -7) === 'TextUrl') {
            return 'url';
        }
        if ($type === 'select' && substr($skin, -6) === '@radio') {
            return 'radio';
        }
        return $type;
    }

    /** 엔진 형식 이름 (fieldType/xpressengine@Text → text) */
    private static function engineType($config)
    {
        $id = (string)$config->get('typeId');
        $at = strrpos($id, '@');
        return strtolower($at === false ? $id : substr($id, $at + 1));
    }

    private static function label($config)
    {
        return trim(strip_tags((string)xe_trans((string)$config->get('label'))));
    }

    /** 예/아니오 항목의 두 글자 (웹 양식과 같은 글자: 관리자가 정한 것, 없으면 엔진 문구) */
    private static function yesNo($config)
    {
        return [
            trim((string)$config->get('radioLabelYes')) ?: (string)xe_trans('xe::yes'),
            trim((string)$config->get('radioLabelNo')) ?: (string)xe_trans('xe::no'),
        ];
    }

    /** 분류 항목의 [분류 항목 id => 글자] (웹 양식 CategorySkin 과 같은 목록) */
    private static function categoryItems($config)
    {
        $id = $config->get('category_id') ?: $config->get('categoryId');
        $category = $id ? \Xpressengine\Category\Models\Category::find($id) : null;
        $items = [];
        if ($category) {
            foreach ($category->items as $item) {
                $items[(string)$item->id] = trim(strip_tags((string)xe_trans((string)$item->word)));
            }
        }
        return $items;
    }

    private static function options($config, $appType)
    {
        $typeId = (string)$config->get('typeId');
        if ($typeId === 'fieldType/xpressengine@Boolean') {
            return self::yesNo($config);
        }
        if ($typeId === 'fieldType/xpressengine@Category') {
            return array_values(array_filter(self::categoryItems($config), 'strlen'));
        }
        return [];
    }

    /** board.extra_keys (XE·Rhymix 모듈과 같은 꼴): [{idx, name, type, engine_type, required, options, parts, default, desc, editable}] */
    public static function keys($boardConfig)
    {
        $out = [];
        foreach (self::definitions($boardConfig) as $idx => list($config)) {
            $appType = self::appType($config);
            $engineType = self::engineType($config);
            $out[] = [
                'idx' => $idx,
                'name' => self::label($config),
                'type' => $appType ?: $engineType,
                'engine_type' => $engineType,
                'required' => $config->get('required') === true,
                'options' => $appType ? self::options($config, $appType) : [],
                'parts' => $appType === 'kr_zip' ? self::ZIP_PARTS : [],
                'default' => '',
                'desc' => trim(strip_tags((string)xe_trans((string)$config->get('skinDescription', '')))),
                'editable' => $appType !== null,
            ];
        }
        return $out;
    }

    // ---- 저장된 값

    /** 이 글의 항목 값 [<항목 id>_<칸> => 값]: 엔진의 DynamicField 프록시로 글과 함께 읽는다(웹이 정렬·검색 항목을 읽는 것과 같은 join) */
    private static function stored(Board $doc)
    {
        static $cache = [];
        if (!isset($cache[$doc->id])) {
            $cache[$doc->id] = [];
            try {
                $documents = app('xe.document');
                $options = $documents->proxyOption($documents->getConfig($doc->instance_id));
                if ($options) {
                    $row = XeDB::connection()->dynamic($doc->getTable(), $options)->where('id', $doc->id)->first();
                    $cache[$doc->id] = $row ? (array)$row : [];
                }
            } catch (\Throwable $e) {
                report($e);
            }
        }
        return $cache[$doc->id];
    }

    /** 한 항목의 칸 값 [칸 => 글자] */
    private static function columns($config, $type, array $row)
    {
        $out = [];
        foreach ($type->getColumns() as $name => $column) {
            $value = $row[$config->get('id') . '_' . $name] ?? null;
            $out[$name] = $value === null ? '' : trim((string)$value);
        }
        return $out;
    }

    /** 칸 값 → 앱 꼴의 글자 (me.form 과 같은 꼴: 주소는 칸마다 줄, 예/아니오·분류는 보기 글자) */
    private static function toApp($config, array $columns)
    {
        switch ((string)$config->get('typeId')) {
            case 'fieldType/xpressengine@Boolean':
                $v = $columns['boolean'] ?? '';
                if ($v === '') {
                    return '';
                }
                list($yes, $no) = self::yesNo($config);
                return $v ? $yes : $no;
            case 'fieldType/xpressengine@Category':
                $id = $columns['item_id'] ?? '';
                return $id === '' ? '' : (self::categoryItems($config)[$id] ?? '');
            case 'fieldType/xpressengine@Address':
                $lines = [$columns['postcode'] ?? '', $columns['address1'] ?? '', $columns['address2'] ?? ''];
                return implode('', $lines) === '' ? '' : implode("\n", $lines);
            default:
                return implode(' ', array_filter($columns, 'strlen'));
        }
    }

    /** document.source.extra_values: {idx: 앱 꼴의 값} */
    public static function values(Board $doc, $boardConfig)
    {
        $row = self::stored($doc);
        $out = new \stdClass;
        foreach (self::definitions($boardConfig) as $idx => list($config, $type)) {
            if (self::appType($config) !== null) {
                $out->{$idx} = self::toApp($config, self::columns($config, $type, $row));
            }
        }
        return $out;
    }

    /**
     * 글 보기의 extra_vars: [{name, type, value_html}]. 웹 글 보기처럼 항목 스킨의 보기 화면(show)을 그대로 그리고 이름표(label)만 뺀다.
     * 값이 하나도 없는 항목은 뺀다(XE·Rhymix 모듈과 같다)
     */
    public static function display(Board $doc, $boardConfig)
    {
        $defs = self::definitions($boardConfig);
        if (!$defs) {
            return [];
        }
        $row = self::stored($doc);
        $out = [];
        foreach ($defs as list($config, $type)) {
            $columns = self::columns($config, $type, $row);
            if (implode('', $columns) === '') {
                continue;
            }
            $html = '';
            try {
                $skin = $type->getSkin();
                $html = $skin ? (string)$skin->show($row) : '';
            } catch (\Throwable $e) {
                report($e);
            }
            // 이름표를 빼고 줄바꿈(<br>)만 남긴 글자. 스킨이 아무것도 그리지 않으면 앱 꼴의 값
            $html = preg_replace('#<label\b[^>]*>.*?</label>#is', '', $html);
            $html = preg_replace('#<br\s*/?>#i', "\x01", $html);
            $text = trim(str_replace("\x01", "\n", preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($html), ENT_QUOTES, 'UTF-8'))));
            $text = trim(preg_replace('/ *\n */', "\n", $text));
            if ($text === '') {
                $text = self::toApp($config, $columns);
            }
            $out[] = ['name' => self::label($config), 'type' => self::engineType($config), 'value_html' => str_replace("\n", '<br>', htmlspecialchars($text, ENT_QUOTES, 'UTF-8'))];
        }
        return $out;
    }

    // ---- 앱이 보낸 값

    /** 앱이 보낸 extra_vars ({idx: 값}, JSON 객체 또는 그 글자). 보내지 않았으면 null */
    private static function input()
    {
        $input = Api::$request->input('extra_vars');
        if (is_string($input)) {
            $input = json_decode($input, true);
        }
        return is_array($input) ? $input : null;
    }

    /** 앱 꼴의 값 → 엔진 양식 값 [<항목 id>_<칸> => 값]. 보기에 없는 값은 400 invalid_field */
    private static function toEngine($config, $type, $raw)
    {
        $id = (string)$config->get('id');
        $value = is_array($raw) ? implode(', ', array_map('strval', array_filter($raw, 'is_scalar'))) : (is_scalar($raw) ? (string)$raw : '');
        $value = mb_substr(trim(str_replace("\r", '', $value)), 0, 5000);
        switch ((string)$config->get('typeId')) {
            case 'fieldType/xpressengine@Boolean':
                list($yes, $no) = self::yesNo($config);
                if ($value === '') {
                    return [$id . '_boolean' => null];
                }
                if ($value === $yes || $value === '1') {
                    return [$id . '_boolean' => '1'];
                }
                if ($value === $no || $value === '0') {
                    return [$id . '_boolean' => '0'];
                }
                throw new ApiError(400, 'invalid_field', self::label($config));
            case 'fieldType/xpressengine@Category':
                if ($value === '') {
                    return [$id . '_item_id' => null];
                }
                $itemId = array_search($value, self::categoryItems($config), true);
                if ($itemId === false) {
                    throw new ApiError(400, 'invalid_field', self::label($config));
                }
                return [$id . '_item_id' => (string)$itemId];
            case 'fieldType/xpressengine@Address':
                $lines = array_pad(array_map('trim', explode("\n", $value)), 3, '');
                return [$id . '_postcode' => mb_substr($lines[0], 0, 8), $id . '_address1' => $lines[1], $id . '_address2' => implode(' ', array_filter(array_slice($lines, 2), 'strlen'))];
            default:
                $out = [];
                foreach (array_keys($type->getColumns()) as $name) {
                    $out[$id . '_' . $name] = $value === '' ? null : str_replace("\n", self::appType($config) === 'textarea' ? "\n" : ' ', $value);
                }
                return $out;
        }
    }

    /**
     * 앱이 보낸 값을 엔진 양식 값으로 바꾸고 웹 글쓰기와 같은 항목 규칙으로 확인한다. [바꿀 값, 보냈는지].
     * $doc 이 있으면(고치기) 보내지 않은 항목은 저장된 값으로 확인하고 그대로 둔다. 예전 앱이 고칠 때(extra_vars 없음)는 확인하지 않는다.
     * 글쓰기는 보내지 않아도 확인한다(웹처럼 필수 항목이 비면 쓸 수 없다)
     */
    public static function inputs($boardConfig, Board $doc = null)
    {
        $defs = self::definitions($boardConfig);
        $input = self::input();
        if (!$defs || ($doc && $input === null)) {
            return [[], false];
        }
        $input = $input ?: [];
        $values = [];
        foreach ($defs as $idx => list($config, $type)) {
            if (self::appType($config) !== null && array_key_exists((string)$idx, $input)) {
                $values += self::toEngine($config, $type, $input[(string)$idx]);
            }
        }
        // 확인할 값: 고치기면 저장된 값 위에 보낸 값
        $check = [];
        if ($doc) {
            $row = self::stored($doc);
            foreach ($defs as list($config, $type)) {
                foreach (array_keys($type->getColumns()) as $name) {
                    $key = $config->get('id') . '_' . $name;
                    $check[$key] = isset($row[$key]) && (string)$row[$key] !== '' ? (string)$row[$key] : null;
                }
            }
        }
        $check = array_merge($check, $values);
        $rules = [];
        $names = [];
        foreach ($defs as list($config, $type)) {
            foreach ($type->getRules() as $key => $rule) {
                $rules[$key] = $rule;
                $names[$key] = self::label($config);
            }
        }
        $validator = \Validator::make($check, $rules, [], $names);
        if ($validator->fails()) {
            throw new ApiError(400, 'invalid_field', $validator->errors()->first());
        }
        return [$values, true];
    }

    /** 고친 글의 항목 값을 엔진의 DynamicField 프록시로 저장한다 (웹 글 고치기의 프록시 update 와 같은 길, 보낸 항목만) */
    public static function save(Board $doc, $boardConfig, array $values)
    {
        if (!$values) {
            return;
        }
        $documents = app('xe.document');
        $options = $documents->proxyOption($documents->getConfig($doc->instance_id));
        if (!$options) {
            return;
        }
        XeDB::connection()->dynamic($doc->getTable(), $options)->where('id', $doc->id)->update($values);
        // 엔진은 빈 값을 '' 로 넣어 숫자·예/아니오 칸이 0(=아니오)이 된다(칸이 NOT NULL). 앱에서 모든 칸을 비운 항목은
        // 값 줄을 지워 처음부터 넣지 않은 것(글쓰기에서 비운 것)과 같게 둔다
        foreach (self::definitions($boardConfig) as list($config, $type)) {
            $sent = 0;
            $empty = 0;
            foreach (array_keys($type->getColumns()) as $name) {
                $key = $config->get('id') . '_' . $name;
                if (array_key_exists($key, $values)) {
                    $sent++;
                    $empty += ($values[$key] === null || $values[$key] === '') ? 1 : 0;
                }
            }
            if ($sent > 0 && $sent === $empty && $sent === count($type->getColumns())) {
                XeDB::connection()->table($type->getTableName())->where('target_id', $doc->id)
                    ->where('field_id', $config->get('id'))->where('group', $config->get('group'))->delete();
            }
        }
    }

    // ---- 태그

    /**
     * 글 보기 끝에 붙이는 태그 (게시판이 태그를 쓸 때, 웹 글 보기 아래의 태그 목록과 같다):
     * <hr><p class="bh-tags">#태그1 #태그2</p>. 글자만(링크 없음), 태그가 없으면 빈 글자
     */
    public static function tagsHtml(Board $doc, $boardConfig)
    {
        if ($boardConfig->get('useTag') != true) {
            return '';
        }
        try {
            $words = [];
            foreach ($doc->tags as $tag) {
                $word = trim((string)$tag->word);
                if ($word !== '') {
                    $words[] = '#' . htmlspecialchars($word, ENT_QUOTES, 'UTF-8');
                }
            }
        } catch (\Throwable $e) {
            report($e);
            return '';
        }
        return $words ? '<hr><p class="bh-tags">' . implode(' ', $words) . '</p>' : '';
    }
}
