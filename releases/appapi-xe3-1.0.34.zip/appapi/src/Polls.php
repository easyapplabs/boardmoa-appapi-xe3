<?php
namespace Xpressengine\Plugins\Appapi;

use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

/**
 * 글 속 설문(투표): xe_poll 플러그인(편집 도구 editortool/poll_tool@poll). XE1 모듈 Polls 와 같은 규약(docs/API.md '글 속 설문').
 *
 * 웹은 본문을 그릴 때 편집 도구가 설문 자리를 투표 폼(세션·CSRF 필요)과 결과 화면으로 바꾼다.
 * 앱이 with_polls=1 을 보내면 그 자리를 자리표시 <div data-bh-poll="번호"></div> 로 바꾸고 설문 내용을 데이터로 준다.
 * 투표는 웹 UserController::toolJoin 과 같은 확인(로그인·마감·이미 참여)을 하고 같은 핸들러(storeLog·increasePollCount)로 넣는다.
 */
class Polls
{
    const POLL = '\Xpressengine\Plugins\Poll\Models\Poll';
    const LOG = '\Xpressengine\Plugins\Poll\Models\PollLog';

    /** 투표 플러그인이 켜져 있는가 */
    public static function available()
    {
        return app()->bound('xe.xe_poll.handler') && class_exists(self::POLL);
    }

    /** 저장된 본문에 든 설문 번호들 (편집 도구가 넣는 <img class="__xe_poll" data-id="…">) */
    public static function idsIn($content)
    {
        $ids = [];
        if (!self::available() || stripos((string)$content, '__xe_poll') === false) {
            return $ids;
        }
        if (preg_match_all('/<[a-z][^>]*\bclass\s*=\s*(["\'])[^"\']*\b__xe_poll(?![\w-])[^"\']*\1[^>]*>/i', (string)$content, $tags)) {
            foreach ($tags[0] as $tag) {
                if (preg_match('/\bdata-id\s*=\s*["\']?(\d+)/i', $tag, $m)) {
                    $ids[] = (int)$m[1];
                }
            }
        }
        return array_values(array_unique($ids));
    }

    /**
     * 엔진이 그린 본문에서 설문 화면(.__xe_poll_section)을 자리표시로 바꾼다. 설문 화면이 처음 한 번 넣는 <style> 도 뺀다.
     * 바꾼 설문 번호(순서대로)를 $found 에. 편집 도구가 그리지 않은 설문 자리(웹에서도 투표 화면이 안 나오는 꼴)는 그대로 둔다.
     */
    public static function replaceRendered($html, array $ids, &$found)
    {
        $found = [];
        if (!$ids || trim((string)$html) === '' || !class_exists('DOMDocument')) {
            return $html;
        }
        $dom = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="utf-8"?><div id="appapi-root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        $xpath = new \DOMXPath($dom);
        $has = function ($class) {
            return "contains(concat(' ', normalize-space(@class), ' '), ' $class ')";
        };
        $changed = false;
        foreach (iterator_to_array($xpath->query('//style')) as $style) {
            if (strpos($style->textContent, '__xe_poll_section') !== false) {
                $style->parentNode->removeChild($style);
                $changed = true;
            }
        }
        $targets = [];
        foreach (iterator_to_array($xpath->query('//*[' . $has('__xe_poll_section') . ']')) as $section) {
            $holder = $xpath->query('.//*[@data-id]', $section)->item(0);
            $targets[] = [$section, $holder ? (int)$holder->getAttribute('data-id') : 0];
        }
        foreach ($targets as $target) {
            list($node, $id) = $target;
            if (!$node->parentNode) {
                continue;
            }
            if (!in_array($id, $ids, true)) {
                continue;
            }
            $placeholder = $dom->createElement('div');
            $placeholder->setAttribute('data-bh-poll', (string)$id);
            $node->parentNode->replaceChild($placeholder, $node);
            $found[] = $id;
            $changed = true;
        }
        if (!$changed) {
            return $html;
        }
        $root = $dom->getElementById('appapi-root') ?: $dom->getElementsByTagName('div')->item(0);
        $out = '';
        foreach ($root->childNodes as $child) {
            $out .= $dom->saveHTML($child);
        }
        // 위 순서는 설문 화면 먼저라 본문 순서와 다를 수 있다: 자리표시 순서로 다시
        if (preg_match_all('/data-bh-poll="(\d+)"/', $out, $m)) {
            $found = array_values(array_unique(array_map('intval', $m[1])));
        }
        return trim($out);
    }

    /** 설문 하나 (XE1 모듈과 같은 모양) */
    public static function info($id)
    {
        $class = self::POLL;
        $poll = self::available() ? $class::find((int)$id) : null;
        if (!$poll) {
            return null;
        }
        $expired = $poll->expired_at ? Carbon::now()->gt($poll->expired_at) : false;
        $log = self::LOG;
        $joined = Auth::check() && $log::where('poll_id', $poll->id)->where('user_id', Auth::id())->exists();
        $questions = [];
        foreach ($poll->items()->orderBy('id')->get() as $item) {
            $choices = [];
            foreach ($item->options()->orderBy('id')->get() as $option) {
                $choices[] = ['id' => (int)$option->id, 'title' => (string)$option->title, 'count' => (int)$option->poll_count];
            }
            $checkcount = max(1, (int)$item->check_count);
            $questions[] = [
                'id' => (int)$item->id,
                'title' => (string)$item->title,
                'checkcount' => $checkcount,
                // 웹 스킨 스크립트와 같은 규칙: 한 개 고르는 질문은 하나(라디오), 여러 개는 적어도 checkcount 개
                'min_choices' => max(1, min($checkcount, count($choices))),
                'max_choices' => $checkcount === 1 ? 1 : max(1, count($choices)),
                'count' => (int)$item->poll_count,
                'choices' => $choices,
            ];
        }
        return [
            'id' => (int)$poll->id,
            'title' => (string)$poll->title !== '' ? (string)$poll->title : null,
            'questions' => $questions,
            'participants' => (int)$poll->poll_count,
            'end_date' => $poll->expired_at ? $poll->expired_at->format('Y-m-d') : null,
            'ended' => $expired,
            'voted' => $joined,
            // 웹은 로그인한 회원만 받는다
            'can_vote' => Auth::check() && !$expired && !$joined && count($questions) > 0,
            'login_required' => true,
            'result_visible' => true,
        ];
    }

    public static function infos(array $ids)
    {
        $polls = [];
        foreach (array_unique($ids) as $id) {
            if ($info = self::info($id)) {
                $polls[] = $info;
            }
        }
        return $polls;
    }

    /** POST poll.vote {mid, document_srl, poll_id, choices: [선택지 번호…]} → {poll} */
    public static function vote()
    {
        // 글을 읽을 수 있고, 웹 본문에 투표 화면으로 나오는 설문이어야 한다
        list(, $rendered) = Boards::readableForPoll(Api::param('mid'), Api::intParam('document_srl'));
        $id = Api::intParam('poll_id');
        if (!$id || !in_array($id, $rendered, true) || !($info = self::info($id))) {
            throw new ApiError(404, 'poll_not_found', '설문을 찾을 수 없습니다.');
        }
        if (!Auth::check()) {
            throw new ApiError(401, 'login_required', '로그인이 필요한 서비스입니다. 로그인 후 이용해주세요.');
        }
        if ($info['ended']) {
            throw new ApiError(400, 'poll_ended', '투표가 종료되었습니다.');
        }
        if ($info['voted']) {
            throw new ApiError(400, 'vote_failed', '이미 참여했습니다.');
        }

        $raw = Api::arrayParam('choices');
        if (count($raw) === 1) {
            $raw = explode(',', (string)reset($raw)); // choices=1,2 (한 글자로 보낸 것)
        }
        $picked = [];
        foreach ($raw as $value) {
            if (ctype_digit(trim((string)$value))) {
                $picked[(int)$value] = true;
            }
        }
        $selected = [];
        foreach ($info['questions'] as $question) {
            $count = 0;
            foreach ($question['choices'] as $choice) {
                if (isset($picked[$choice['id']])) {
                    $selected[] = $choice['id'];
                    unset($picked[$choice['id']]);
                    $count++;
                }
            }
            if ($count < $question['min_choices'] || $count > $question['max_choices']) {
                throw new ApiError(400, 'invalid_choice', '답변 항목 수를 확인하세요.');
            }
        }
        if ($picked) {
            throw new ApiError(400, 'invalid_choice', '답변 항목 수를 확인하세요.');
        }

        $handler = app('xe.xe_poll.handler');
        \XeDB::beginTransaction();
        try {
            $log = $handler->storeLog([
                'user_id' => Auth::id(),
                'poll_id' => $id,
                'ipaddress' => Api::$request->ip(),
                'options_ids' => implode(',', $selected),
                'created_at' => Carbon::now(),
            ]);
            $handler->increasePollCount($log);
            \XeDB::commit();
        } catch (\Throwable $e) {
            \XeDB::rollback();
            throw $e;
        }
        return ['poll' => self::info($id)];
    }
}
