<?php
namespace Xpressengine\Plugins\Appapi;

use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Xpressengine\Category\Models\CategoryItem;
use Xpressengine\Plugins\Board\Models\Board;

/**
 * 위젯 페이지(widget_page 플러그인, 사이트 기본 홈)를 앱에서 그릴 HTML 로 만든다.
 *
 * 웹은 xe_widgetbox(id 'widgetpage-<메뉴 id>')의 JSON 으로 위젯 스킨을 그리지만, 그 HTML 은 테마 CSS·스크립트에 기대고
 * 최신글 위젯(widget/board@list)은 게시판 권한을 보지 않는다(관리자 전용 게시판 제목이 비회원에게 보인다).
 * 그래서 웹 위젯 HTML 을 쓰지 않고 같은 설정값으로 직접 만든다:
 *   - widget/board@list: 웹 위젯과 같은 조건(게시판·분류·공지·최근 며칠·정렬·개수)에, 이 회원이 목록을 볼 수 있는 게시판만
 *     (메뉴에서 보이고 목록 권한, 상담 게시판은 관리자가 아니면 자기 글만 — 게시판 목록과 같은 판단). 남는 글이 없으면 위젯째 뺀다
 *   - widget/banner@widget: 보이는 배너(상태·기간)의 그림·제목·링크. 이 회원이 볼 수 없는 게시판으로 가는 배너는 뺀다
 *   - 그 밖의 위젯(관리자 대시보드용 등)은 뺀다
 */
class Widgets
{
    const LIST_WIDGET = 'widget/board@list';
    const BANNER_WIDGET = 'widget/banner@widget';
    /** 위젯 하나에서 보일 글 수 상한 */
    const MAX_TAKE = 30;

    /** 위젯 페이지 메뉴 항목 → 앱용 HTML (그릴 위젯이 없으면 '') */
    public static function page($item)
    {
        $box = self::box('widgetpage-' . $item->id);
        if (!$box) {
            return '';
        }
        $widgets = [];
        self::collect($box, $widgets);
        $out = [];
        foreach ($widgets as $widget) {
            $id = (string)($widget['@attributes']['id'] ?? '');
            try {
                if ($id === self::LIST_WIDGET) {
                    $out[] = self::articleList($widget);
                } elseif ($id === self::BANNER_WIDGET) {
                    $out[] = self::banner($widget);
                }
            } catch (\Throwable $e) {
                report($e); // 위젯 하나가 깨져도 나머지는 보인다
            }
        }
        // 배너 링크 같은 XE3 글 주소에도 mid·document_srl 을 붙인다
        return trim(Content::clean(implode("\n", array_filter($out))));
    }

    private static function box($id)
    {
        $class = '\Xpressengine\Widget\Models\WidgetBox';
        if (!class_exists($class)) {
            return null;
        }
        $box = $class::find($id);
        $content = $box ? $box->content : null;
        if (is_string($content)) {
            $content = json_decode($content, true);
        }
        return is_array($content) ? $content : null;
    }

    /** 줄(cols·rows·widgets) 안의 위젯을 화면 순서대로 */
    private static function collect($node, array &$widgets)
    {
        if (!is_array($node)) {
            return;
        }
        if (isset($node['@attributes']['id'])) {
            $widgets[] = $node;
            return;
        }
        foreach ($node as $child) {
            self::collect($child, $widgets);
        }
    }

    private static function title($widget)
    {
        return trim(strip_tags(xe_trans((string)($widget['@attributes']['title'] ?? ''))));
    }

    // ---- 최신글

    private static function articleList($widget)
    {
        $selected = $widget['board_id'] ?? [];
        $selected = is_array($selected) ? (array)($selected['item'] ?? $selected) : [(string)$selected];
        $selected = array_values(array_filter(array_map('strval', $selected), 'strlen'));
        $boardIds = array_values(array_filter($selected, function ($id) { return mb_substr($id, 0, 9) !== 'category.'; }));
        $categoryIds = [];
        foreach ($selected as $id) {
            if (mb_substr($id, 0, 9) === 'category.' && ($c = CategoryItem::find(mb_substr($id, 9)))) {
                foreach ($c->getDescendantTree(true)->getNodes()->pluck('id') as $cid) {
                    $categoryIds[] = $cid;
                }
            }
        }

        // 이 회원이 목록을 볼 수 있는 게시판만 (웹 위젯은 권한을 보지 않는다)
        $visible = Boards::visibleBoards();
        $user = Auth::user();
        $open = [];
        $ownOnly = [];
        foreach ($visible as $instanceId => $menuItem) {
            $config = app('xe.board.config')->get($instanceId);
            if (!$config) {
                continue;
            }
            if ($config->get('useConsultation') === true && !Boards::grant($instanceId)['manager']) {
                $ownOnly[] = $instanceId;
            } else {
                $open[] = $instanceId;
            }
        }
        if (!Auth::check()) {
            $ownOnly = [];
        }
        if (!$open && !$ownOnly) {
            return '';
        }

        $query = Board::query()->where(function ($q) use ($open, $ownOnly, $user) {
            if ($open) {
                $q->whereIn('instance_id', $open);
            }
            if ($ownOnly) {
                $q->orWhere(function ($q) use ($ownOnly, $user) {
                    $q->whereIn('instance_id', $ownOnly)->where('user_id', $user->getId());
                });
            }
        });
        // 위젯 설정의 대상 (웹 ArticleListWidget 과 같은 조건)
        if ($boardIds && $categoryIds) {
            $query->where(function ($q) use ($boardIds, $categoryIds) {
                $q->whereIn('instance_id', $boardIds)->orWhereHas('boardCategory', function ($q) use ($categoryIds) {
                    $q->whereIn('item_id', $categoryIds);
                });
            });
        } elseif ($boardIds) {
            $query->whereIn('instance_id', $boardIds);
        } elseif ($categoryIds) {
            $query->whereHas('boardCategory', function ($q) use ($categoryIds) {
                $q->whereIn('item_id', $categoryIds);
            });
        } elseif ($selected) {
            return ''; // 고른 분류가 모두 지워졌다
        }

        switch ((string)($widget['noticeInList'] ?? ($widget['notice_type'] ?? 'withOutNotice'))) {
            case 'onlyNotice':
                $query->notice();
                break;
            case 'on':
            case 'withNotice':
                $query->visibleWithNotice();
                break;
            default:
                $query->visible();
                break;
        }
        // 공지 포함·공지만에도 승인 안 된 남의 글은 빼고 (게시판 목록과 같게)
        $query->where(function ($q) use ($user) {
            $q->where('approved', Board::APPROVED_APPROVED);
            if (Auth::check()) {
                $q->orWhere('user_id', $user->getId());
            }
        });

        $recent = (int)($widget['recent_date'] ?? 0);
        if ($recent > 0) {
            $query->where('created_at', '>=', Carbon::now()->subDays($recent)->toDateString() . ' 00:00:00');
        }
        $order = (string)($widget['order_type'] ?? '');
        if ($order === 'assent_count') {
            $query->orderBy('assent_count', 'desc');
        } elseif ($order === 'recentlyCreated') {
            $query->orderBy(Board::CREATED_AT, 'desc');
        } elseif ($order === 'recentlyUpdated') {
            $query->orderBy(Board::UPDATED_AT, 'desc');
        }
        $query->orderBy('head', 'desc');
        $take = (int)($widget['take'] ?? 0);
        $query->take($take > 0 ? min($take, self::MAX_TAKE) : 10);

        $skin = strtolower((string)($widget['@attributes']['skin-id'] ?? ''));
        $withThumb = (bool)preg_match('/gallery|media|webzine|blog/', $skin);
        $rows = [];
        foreach ($query->get() as $doc) {
            $menuItem = $visible[$doc->instance_id] ?? null;
            $config = app('xe.board.config')->get($doc->instance_id);
            if (!$menuItem || !$config) {
                continue;
            }
            $s = Boards::summary($doc, $config, Boards::grant($doc->instance_id)['view']);
            $href = Boards::absolute(app('xe.board.url')->getShow($doc, [], $config));
            $href .= (strpos($href, '?') === false ? '?' : '&') . 'mid=' . rawurlencode((string)$menuItem->url) . '&document_srl=' . $s['document_srl'];
            $thumb = ($withThumb && $s['thumbnail'])
                ? '<img src="' . e($s['thumbnail']) . '" alt="" style="width:88px;vertical-align:middle;margin-right:8px">' : '';
            $meta = array_filter([
                $s['regdate'] ? Carbon::parse($s['regdate'])->format('Y-m-d') : '',
                $s['author'],
                $s['comment_count'] > 0 ? Text::t('댓글 {0}', $s['comment_count']) : '',
            ], 'strlen');
            $rows[] = '<li><a href="' . e($href) . '">' . $thumb . ($s['is_secret'] ? '🔒 ' : '') . e($s['title']) . '</a>'
                . ($meta ? '<br><small>' . e(implode(' · ', $meta)) . '</small>' : '') . '</li>';
        }
        if (!$rows) {
            return '';
        }
        $title = self::title($widget);
        // 게시판 하나만 고른 위젯이면 제목을 그 게시판 링크로 (웹의 '더보기')
        if ($title !== '' && count($boardIds) === 1 && !$categoryIds && isset($visible[$boardIds[0]])) {
            $title = '<a href="' . e(Boards::absolute($visible[$boardIds[0]]->url)) . '">' . e($title) . '</a>';
        } else {
            $title = e($title);
        }
        return '<section class="bh-widget bh-widget-list">' . ($title !== '' ? '<h3>' . $title . '</h3>' : '')
            . '<ul>' . implode('', $rows) . '</ul></section>';
    }

    // ---- 배너

    private static function banner($widget)
    {
        if (!app()->bound('xe.banner')) {
            return '';
        }
        $handler = app('xe.banner');
        $group = $handler->getGroup((string)($widget['group_id'] ?? ''));
        if (!$group) {
            return '';
        }
        try {
            $count = $group->getSkinInfo('count');
        } catch (\Throwable $e) {
            $count = null;
        }
        $items = [];
        foreach ($handler->getItems($group, $count, true) as $banner) {
            $link = trim((string)$banner->link);
            if ($link !== '' && !self::linkVisible($link)) {
                continue; // 볼 수 없는 게시판·페이지로 가는 배너
            }
            $image = (string)array_get((array)$banner->image, 'path', '');
            if ($image === '') {
                try {
                    $image = (string)$banner->imageUrl();
                } catch (\Throwable $e) {
                    $image = '';
                }
            }
            $title = trim(strip_tags((string)$banner->title));
            $body = ($image !== '' ? '<img src="' . e(Boards::absolute($image)) . '" alt="' . e($title) . '">' : '')
                . ($title !== '' ? '<br><strong>' . e($title) . '</strong>' : '');
            if ($body === '') {
                continue;
            }
            $items[] = '<p>' . ($link !== '' ? '<a href="' . e(Boards::absolute($link)) . '">' . $body . '</a>' : $body) . '</p>';
        }
        if (!$items) {
            return '';
        }
        return '<section class="bh-widget bh-widget-banner">' . implode('', $items) . '</section>';
    }

    /** 같은 사이트 메뉴(게시판·페이지·글)로 가는 링크면 이 회원이 그 메뉴를 볼 수 있는지. 다른 곳이면 true */
    private static function linkVisible($link)
    {
        $found = Content::documentOfUrl($link);
        if (!$found) {
            $path = parse_url($link, PHP_URL_PATH);
            $host = parse_url($link, PHP_URL_HOST);
            $site = parse_url(url('/'), PHP_URL_HOST);
            $same = !$host || strtolower(preg_replace('/^www\./i', '', $host)) === strtolower(preg_replace('/^www\./i', '', (string)$site));
            if ($same && is_string($path) && preg_match('#^/?([A-Za-z0-9_\-]{1,80})(/|$)#', ltrim($path, '/'), $m)) {
                $item = \XeMenu::items()->query()->where('url', $m[1])->first();
                return !$item || Boards::isVisible($item);
            }
            return true;
        }
        return Boards::isVisible($found['item']);
    }
}
