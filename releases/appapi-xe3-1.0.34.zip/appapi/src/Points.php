<?php
namespace Xpressengine\Plugins\Appapi;

use Auth;

/**
 * 포인트 플러그인(xpressengine/plugin-point)이 웹 게시판 화면(BoardModuleController)에서만 하는 판단을 앱 요청에서도 한다.
 * 플러그인은 읽기·추천받기·편집기 파일 올리기·내려받기를 '지금 웹 게시판 화면인가'로 거르기 때문에,
 * 그대로 두면 앱으로는 포인트가 모자라도 읽고 받을 수 있다(웹보다 넓어진다). 같은 동작 이름·같은 규칙으로 부른다.
 * 글쓰기·댓글 포인트는 플러그인이 화면과 상관없이 하므로 여기서 하지 않는다(두 번 깎이지 않게).
 */
class Points
{
    /** 포인트 플러그인이 켜져 있고 '포인트 기능 사용'이면 그 핸들러 */
    public static function handler()
    {
        if (!app()->bound('point::handler')) {
            return null;
        }
        $handler = app('point::handler');
        return $handler->isUse() ? $handler : null;
    }

    /** 플러그인 설정의 '특정 그룹만 적용' (그 그룹이 아니면 포인트를 따지지 않는다) */
    private static function applies($user)
    {
        $config = app('config')->get('point');
        if (!empty($config['specific_group'])) {
            return $user && $user->specific === true;
        }
        return true;
    }

    /** 모자라면 웹과 같은 안내로 막는다 */
    public static function ensure($action, $user, $message)
    {
        $handler = self::handler();
        if ($handler && self::applies($user) && $handler->checkAction($action, $user) == false) {
            throw new ApiError(403, 'point_shortage', $message);
        }
    }

    public static function execute($action, $user, array $data)
    {
        $handler = self::handler();
        if ($handler && (is_string($user) || self::applies($user))) {
            $handler->executeAction($action, $user, $data);
        }
    }

    /**
     * 글 읽기: 조회수를 올리고, 처음 읽는 남의 일반 글이면 포인트를 확인·적용한다 (웹 point.read-document 와 같은 조건).
     * 모자라면 조회수도 되돌리고 막는다.
     */
    public static function read($doc, $user)
    {
        \XeDB::beginTransaction();
        try {
            $before = $doc->read_count;
            app('xe.board.handler')->incrementReadCount($doc, $user);
            $skip = $doc->getAttribute('status') === \Xpressengine\Plugins\Board\Models\Board::STATUS_NOTICE
                || $before == $doc->read_count
                || $doc->getUserId() === $user->getId()
                || $doc->type !== 'module/board@board';
            if (!$skip && self::handler()) {
                $action = 'board.read-document.' . $doc->instance_id;
                self::ensure($action, Auth::user(), '[포인트 부족] 글을 조회할 수 없습니다.');
                self::execute($action, Auth::user(), ['document_id' => $doc->id, 'type' => 'read']);
            }
            \XeDB::commit();
        } catch (\Throwable $e) {
            \XeDB::rollback();
            throw $e;
        }
    }

    /** 추천·비추천을 새로 받았을 때 글쓴이에게 (웹 point.vote-increment-document) */
    public static function voted($doc, $option)
    {
        if (!self::handler() || $doc->type !== 'module/board@board') {
            return;
        }
        $config = app('config')->get('point');
        if (!empty($config['specific_group'])) {
            $owner = app('xe.user')->find($doc->user_id);
            if (!$owner || $owner->specific !== true) {
                return;
            }
        }
        $action = 'board.receive-' . ($option === 'assent' ? 'assent' : 'dissent') . '-document.' . $doc->instance_id;
        self::execute($action, (string)$doc->user_id, ['document_id' => $doc->id]);
    }

    /** 편집기 파일 올리기 한 장마다 (웹 point.board-upload-file-editor) */
    public static function beforeUpload($instanceId)
    {
        self::ensure('board.upload-file.' . $instanceId, Auth::user(), '[포인트 부족] 업로드 할 수 없습니다.');
    }

    public static function uploaded($instanceId)
    {
        self::execute('board.upload-file.' . $instanceId, Auth::user(), ['instance_id' => $instanceId]);
    }

    /** 첨부 내려받기 (사진 제외, 웹 point.board-download-file) */
    public static function beforeDownload($instanceId, $file)
    {
        if (explode('/', (string)$file->mime)[0] === 'image') {
            return false;
        }
        self::ensure('board.download-file.' . $instanceId, Auth::user(), '[포인트 부족] 다운로드 할 수 없습니다.');
        return true;
    }

    public static function downloaded($instanceId, $file)
    {
        self::execute('board.download-file.' . $instanceId, Auth::user(), ['instance_id' => $instanceId, 'file_id' => $file->id, 'mime' => $file->mime]);
    }
}
