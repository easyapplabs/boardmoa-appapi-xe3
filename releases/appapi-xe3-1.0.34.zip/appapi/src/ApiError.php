<?php
namespace Xpressengine\Plugins\Appapi;

/** 앱에 돌려줄 오류 (HTTP 상태, 오류 코드, 사용자에게 보일 문장) */
class ApiError extends \Exception
{
    public $status;
    public $codeName;
    /** error 에 더할 값 (예: captcha_required 의 captcha). code·message 는 덮지 않는다 */
    public $extra;

    public function __construct($status, $code, $message, array $extra = [])
    {
        parent::__construct($message);
        $this->status = $status;
        $this->codeName = $code;
        $this->extra = $extra;
    }
}
