<?php
namespace Xpressengine\Plugins\Appapi;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Xpressengine\User\Models\User;

/**
 * 요청 입구: ?r=<route> 를 처리하고 {"ok", "data"|"error"} 로 답한다.
 */
class Api
{
    const VERSION = '1.0.33';

    /** route => [메서드, 로그인 필요(true)/선택(false)/토큰 안 봄(null), 처리] */
    private static $routes = [
        'site' => ['GET', false, [Boards::class, 'site']],
        'menu' => ['GET', false, [Boards::class, 'menus']],
        'auth.login' => ['POST', null, [self::class, 'login']],
        'auth.refresh' => ['POST', null, [self::class, 'refresh']],
        'auth.logout' => ['POST', null, [self::class, 'logout']],
        // 로그인한 기기 (1.0.19~, 기능 devices): 이 회원의 앱 로그인(토큰)마다 한 줄, 줄마다 로그아웃
        'auth.devices' => ['GET', true, [self::class, 'devices']],
        'auth.devices.revoke' => ['POST', true, [self::class, 'revokeDevice']],
        'me' => ['GET', true, [self::class, 'me']],
        'feed' => ['GET', false, [Boards::class, 'feed']],
        'board' => ['GET', false, [Boards::class, 'board']],
        // POST 도 받는다(0.3.6~): 비회원 비밀글을 비밀번호(password)로 열 때 주소에 남기지 않으려고
        'document' => ['GET|POST', false, [Boards::class, 'document']],
        'comments' => ['GET', false, [Boards::class, 'comments']],
        'page' => ['GET', false, [Boards::class, 'page']],
        'resolve' => ['GET', false, [Boards::class, 'resolve']],
        'file' => ['GET', false, [Boards::class, 'file']],
        // 비회원도 글쓰기 권한이 있으면 쓴다 (0.3.6~, 이름·비밀번호·메일을 받는다)
        'document.write' => ['POST', false, [Write::class, 'insertDocument']],
        // 비회원 글·댓글은 비밀번호로 고치고 지운다 (0.3.6~, 기능 guest_manage). 토큰도 비밀번호도 없으면 예전처럼 401 login_required (Write 가 본다)
        'document.source' => ['GET|POST', false, [Write::class, 'documentSource']],
        'document.update' => ['POST', false, [Write::class, 'updateDocument']],
        'document.delete' => ['POST', false, [Write::class, 'deleteDocument']],
        // 비회원 댓글 (0.3.6~, 기능 guest_comment): 이름·메일·비밀번호
        'comment.write' => ['POST', false, [Write::class, 'insertComment']],
        // 댓글 고치기 (0.3.6~, 기능 comment_edit)
        'comment.update' => ['POST', false, [Write::class, 'updateComment']],
        'comment.delete' => ['POST', false, [Write::class, 'deleteComment']],
        // 댓글 추천 (1.0.18~, 기능 comment_vote). 로그인은 Write::commentVote 가 본다 (비회원은 401 login_required)
        'comment.vote' => ['POST', false, [Write::class, 'commentVote']],
        'document.vote' => ['POST', true, [Write::class, 'vote']],
        'document.voters' => ['GET', false, [Write::class, 'voters']],
        'document.scrap' => ['POST', true, [Write::class, 'scrap']],
        'document.declare' => ['POST', true, [Write::class, 'report']],
        // 로그인은 Polls::vote 가 확인한다(웹과 같은 안내)
        'poll.vote' => ['POST', false, [Polls::class, 'vote']],
        'my.menu' => ['GET', true, [My::class, 'menu']],
        'my.documents' => ['GET', true, [My::class, 'documents']],
        'my.comments' => ['GET', true, [My::class, 'comments']],
        'my.scraps' => ['GET', true, [My::class, 'scraps']],
        'my.scrap.delete' => ['POST', true, [My::class, 'deleteScrap']],
        'me.form' => ['GET', true, [My::class, 'form']],
        'me.update' => ['POST', true, [My::class, 'update']],
        'me.password' => ['POST', true, [My::class, 'password']],
        'me.image' => ['POST', true, [My::class, 'image']],
        'member.menu' => ['GET', false, [My::class, 'memberMenu']],
        // 회원 정보 (1.0.18~): 웹 프로필 화면(/@회원)과 같은 내용
        'member.info' => ['GET', true, [My::class, 'memberInfo']],
        // 가입 (1.0.28~): 웹 가입과 같은 가입 양식 조각 검사·회원 처리기 (Signup)
        'signup.form' => ['GET', false, [Signup::class, 'form']],
        'signup' => ['POST', null, [Signup::class, 'signup']],
        // XE3 에 없는 기능(알림 센터): 앱이 종 아이콘을 숨기도록
        'notify.count' => ['GET', true, [self::class, 'noNotify']],
    ];

    /** @var Request */
    public static $request;
    /** @var object|null 이번 요청의 토큰 행 */
    public static $token;

    public function handle(Request $request)
    {
        self::$request = $request;
        try {
            self::applyLocale($request);
            Store::ensureTables();
            $route = $request->query('r', '');
            $route = is_string($route) ? $route : '';
            if (!isset(self::$routes[$route])) {
                throw new ApiError(404, 'unknown_route', 'unknown route');
            }
            list($method, $login, $handler) = self::$routes[$route];
            $methods = explode('|', $method);
            if (!in_array($request->method(), $methods, true) && !(in_array('GET', $methods, true) && $request->method() === 'HEAD')) {
                throw new ApiError(405, 'method_not_allowed', 'method not allowed');
            }
            if ($login !== null) {
                self::authenticate($login);
            }
            $data = call_user_func($handler);
            if ($data instanceof \Symfony\Component\HttpFoundation\Response) {
                return $data;
            }
            return self::json(['ok' => true, 'data' => $data], 200);
        } catch (ApiError $e) {
            // 플러그인 문구는 한국어 원문이 열쇠다 (영어 사전에 없으면 = 엔진 문구 등 그대로)
            $error = array_merge($e->extra, ['code' => $e->codeName, 'message' => Text::t($e->getMessage())]);
            return self::json(['ok' => false, 'error' => $error], $e->status);
        } catch (\Symfony\Component\HttpKernel\Exception\HttpExceptionInterface $e) {
            // XE3 의 HTTP 예외(게시판 SecretDocumentHttpException 등 HttpXpressengineException)도 이 인터페이스다 (0.3.6~, 전에는 500)
            $status = $e->getStatusCode();
            $code = $status === 404 ? 'not_found' : ($status === 401 || $status === 403 ? 'not_permitted' : 'error');
            if ($status === 403 && !Auth::check()) {
                $status = 401;
            }
            $message = (string)$e->getMessage();
            if (preg_match('/^[\w.\-]+::[\w.\-]+$/', $message)) {
                $message = (string)xe_trans($message); // XE3 예외는 문구 열쇠(board::SecretStatePost 등)를 담는다
            }
            return self::json(['ok' => false, 'error' => ['code' => $code, 'message' => $message ?: self::message($code)]], $status);
        } catch (\Throwable $e) {
            report($e);
            return self::json(['ok' => false, 'error' => ['code' => 'server_error', 'message' => Text::t('서버에서 처리하지 못했습니다.')]], 500);
        } finally {
            // 비밀번호로 확인한 비회원 글·댓글 표시는 이번 요청에서만
            Guest::forget();
        }
    }

    private static function json($body, $status)
    {
        return response()->json($body, $status, ['Cache-Control' => 'no-store'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public static function message($code)
    {
        $messages = [
            'not_found' => '없는 페이지입니다.',
            'not_permitted' => '권한이 없습니다.',
            'login_required' => '로그인이 필요합니다.',
        ];
        return Text::t($messages[$code] ?? '처리하지 못했습니다.');
    }

    /**
     * 앱 언어(X-App-Lang: ko, en, ja, es, pt-BR, de, fr, it, vi, id, zh-Hant, zh-Hans …)가 사이트에서 쓰는 언어면 이번 요청을 그 언어로:
     * 사이트가 넣어 둔 번역(메뉴·게시판 이름 등)과 엔진 문구가 그 언어로 나온다(웹에서 그 언어를 고른 것과 같다).
     * 사이트 로케일과 맞추기: 그대로 같은 것 → 지역 표시를 뺀 언어(pt-BR → pt, 또는 pt → pt-BR) → 중국어 번체(zh-Hant → zh-TW·zh-HK·zh)·간체(zh-Hans → zh-CN·zh).
     * 사이트에 없는 언어면 사이트에 영어가 있을 때 영어. 머리말이 없으면(예전 앱) 그대로(사이트 언어).
     */
    private static function applyLocale(Request $request)
    {
        $tag = strtolower(str_replace('_', '-', trim((string)$request->header('X-App-Lang', ''))));
        // 앱 설정 '게시판 언어: 사이트 기본 언어' (1.0.12~): X-Content-Lang: site 면 사이트 언어 그대로
        if (strtolower(trim((string)$request->header('X-Content-Lang', ''))) === 'site') {
            return;
        }
        if ($tag === '' || !preg_match('/^[a-z]{2,3}(-[a-z0-9]{2,8})*$/', $tag)) {
            return;
        }
        try {
            $translator = app('xe.translator');
            $locales = (array)$translator->getLocales();
            $lower = [];
            foreach ($locales as $loc) {
                $lower[strtolower((string)$loc)] = $loc;
            }
            $base = explode('-', $tag)[0];
            $want = [$tag];
            if ($base === 'zh') {
                $want = array_merge($want, preg_match('/-(hans|cn|sg)\b/', $tag) ? ['zh-cn', 'zh'] : ['zh-tw', 'zh-hk', 'zh-hant', 'zh']);
            } else {
                $want[] = $base;
                foreach (array_keys($lower) as $l) {
                    if (strpos($l, $base . '-') === 0) {
                        $want[] = $l;
                    }
                }
            }
            $pick = null;
            foreach ($want as $w) {
                if (isset($lower[$w])) {
                    $pick = $lower[$w];
                    break;
                }
            }
            if ($pick === null && isset($lower['en'])) {
                $pick = $lower['en']; // 사이트에 없는 언어 → 영어
            }
            if ($pick !== null && $translator->getLocale() !== $pick) {
                $translator->setLocale($pick);
                app()->setLocale($pick);
            }
        } catch (\Throwable $e) {
            report($e);
        }
    }

    /**
     * 글자 값 하나. 배열·객체로 온 값(search_keyword[]=a 등)은 없는 것으로 보고 기본값을 준다
     * (그대로 (string) 으로 바꾸면 PHP 경고가 예외가 되어 500 이었다. 이제 각 처리의 400 검사로 간다)
     */
    public static function param($name, $default = null)
    {
        $value = self::$request->input($name);
        if (is_string($value)) {
            return $value;
        }
        if (is_int($value) || is_float($value) || is_bool($value)) {
            return (string)$value;
        }
        return $default;
    }

    /**
     * 배열로 받는 값(설문 choices 등). 하나만 오면(choices=3 또는 "1,2") 그 글자를 담은 배열.
     * 안쪽 값도 글자·숫자만 남긴다(배열 속 배열은 버린다)
     */
    public static function arrayParam($name)
    {
        $value = self::$request->input($name);
        if ($value === null || $value === '') {
            return [];
        }
        $out = [];
        foreach ((array)$value as $key => $v) {
            if (is_string($v) || is_int($v) || is_float($v)) {
                $out[$key] = (string)$v;
            }
        }
        return $out;
    }

    public static function intParam($name, $default = 0)
    {
        $value = self::$request->input($name);
        return is_numeric($value) ? (int)$value : $default;
    }

    // ---- 인증

    private static function bearer()
    {
        // Apache(mod_php)는 설정에 따라 Authorization 을 PHP 에 넘기지 않는다: 리디렉트 변수·원본 머리말도 본다
        $header = (string)self::$request->header('Authorization', '');
        if ($header === '') {
            $header = (string)($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        }
        if ($header === '' && function_exists('apache_request_headers')) {
            foreach ((array)apache_request_headers() as $name => $value) {
                if (strtolower($name) === 'authorization') {
                    $header = (string)$value;
                }
            }
        }
        return stripos($header, 'Bearer ') === 0 ? trim(substr($header, 7)) : '';
    }

    /** Bearer 토큰으로 회원을 확인하고 이번 요청 동안 그 회원으로 처리한다 */
    private static function authenticate($required)
    {
        $access = self::bearer();
        if ($access === '') {
            if ($required) {
                throw new ApiError(401, 'login_required', self::message('login_required'));
            }
            return;
        }
        $row = Store::findByAccess($access);
        if (!$row) {
            throw new ApiError(401, 'token_expired', 'access token expired');
        }
        $user = self::checkUser($row);
        Auth::setUser($user);
        Store::touch($row);
        self::$token = $row;
    }

    /** 매번 회원 상태를 다시 본다: 탈퇴·비활성·비밀번호 변경이면 토큰 폐기 */
    private static function checkUser($row)
    {
        $user = User::find($row->user_id);
        if (!$user || $user->getStatus() !== User::STATUS_ACTIVATED) {
            Store::revokeUser($row->user_id);
            throw new ApiError(401, 'session_revoked', '로그인할 수 없는 계정입니다.');
        }
        if (!hash_equals($row->password_sig, Store::passwordSig($user->password))) {
            Store::revoke($row->token_id);
            throw new ApiError(401, 'session_revoked', 'password changed');
        }
        return $user;
    }

    public static function login()
    {
        $id = trim((string)self::param('user_id', ''));
        $password = (string)self::param('password', '');
        if ($id === '' || $password === '') {
            throw new ApiError(400, 'missing_credentials', '아이디와 비밀번호를 입력하세요.');
        }
        // 웹 로그인(AuthController::postLogin)과 같은 값으로 같은 Auth::attempt 를 부른다: 아이디 또는 이메일,
        // 다른 플러그인이 로그인을 가로채는 것(휴면 계정 freezer 의 휴면 풀기 등)도 웹과 같이 거친다
        // 로그인 CAPTCHA (1.0.18~, 기능 captcha_solve): 웹 로그인(AuthController::checkCaptcha)과 같은 판단·같은 코어 드라이버로, 비밀번호를 보기 전에 확인한다
        if (Captcha::loginRequired() && !Captcha::verify()) {
            throw Captcha::error(self::param('captcha_response') ? '자동 입력 방지 확인을 통과하지 못했습니다. 다시 해 주세요.' : '자동 입력 방지 확인이 필요합니다.');
        }
        $credentials = ['email' => $id, 'password' => $password,
            'status' => [User::STATUS_ACTIVATED, User::STATUS_PENDING_ADMIN, User::STATUS_PENDING_EMAIL]];
        if (self::frozenNeedsWeb($credentials)) {
            throw new ApiError(403, 'not_permitted', '휴면 계정입니다. 웹사이트에서 로그인해 휴면 상태를 풀어 주세요.');
        }
        $unfrozen = false;
        if (!self::attempt($credentials, $unfrozen)) {
            if (self::socialOnly($id)) {
                throw new ApiError(401, 'login_failed', '소셜 로그인으로 가입한 계정입니다. 웹사이트에서 비밀번호를 정한 뒤 앱에서 로그인해 주세요.');
            }
            throw new ApiError(401, 'login_failed', '아이디 또는 비밀번호가 맞지 않습니다.');
        }
        $user = Auth::user();
        if (!$user || $user->getStatus() !== User::STATUS_ACTIVATED) {
            throw new ApiError(403, 'not_permitted', '승인을 기다리는 계정입니다. 사이트에서 확인해 주세요.');
        }
        $tokens = Store::issue($user->getId(), $user->password, self::param('device_name', ''), self::param('platform', ''), self::$request->ip());
        Auth::setUser($user);
        $result = ['tokens' => $tokens, 'member' => self::profile()];
        if ($unfrozen) {
            // 새 필드(예전 앱은 무시한다): 웹이 띄우는 '휴면 계정 복구' 안내와 같은 뜻
            $result['notice'] = Text::t('휴면 상태였던 계정을 되살리고 로그인했습니다.');
        }
        return $result;
    }

    /** Auth::attempt (세션 가드). 이 요청에는 세션이 없으므로 로그인 상태는 남지 않고, 앱에는 토큰을 준다 */
    private static function attempt(array $credentials, &$unfrozen)
    {
        $frozen = self::freezer() ? app('freezer::handler')->attempt($credentials) : null;
        $ok = (bool)Auth::attempt($credentials, false);
        $unfrozen = $ok && $frozen !== null;
        if ($unfrozen) {
            // freezer 는 웹 이동 응답에 안내를 붙이는 동작(->with('alert'))을 남긴다. JSON 응답에는 붙일 수 없어 그대로 두는 동작으로 바꾼다
            try {
                $plugin = app('xe.plugin')->getPlugin('freezer');
                $object = $plugin ? $plugin->getObject() : null;
                if ($object && method_exists($object, 'addAction')) {
                    $object->addAction('unfreeze_alert', function ($request, $response) {
                        return $response;
                    });
                }
            } catch (\Throwable $e) {
                report($e);
            }
        }
        return $ok;
    }

    /** 휴면 계정 플러그인(freezer)이 켜져 있는가 */
    private static function freezer()
    {
        return app()->bound('freezer::handler');
    }

    /**
     * 휴면 계정인데 사이트가 '휴면 해제 안내 페이지'를 쓰게 해 두었으면 웹에서만 풀 수 있다
     * (freezer 는 그 화면으로 보내려고 세션을 쓴다 — 앱 요청에는 세션이 없다)
     */
    private static function frozenNeedsWeb(array $credentials)
    {
        if (!self::freezer() || !array_get((array)config('services.freezer'), 'use_unfreeze_page')) {
            return false;
        }
        return app('freezer::handler')->attempt($credentials) !== null;
    }

    /**
     * 비밀번호가 없는 회원: social_login 플러그인으로 가입한 회원이다(코어 가입·관리자 추가는 비밀번호가 있어야 한다).
     * 연결된 소셜 계정 행(user_account)은 보지 않는다 — 소셜 계정 연결을 끊어도 비밀번호가 없으면 비밀번호로는 못 들어온다
     */
    private static function socialOnly($id)
    {
        try {
            $user = Auth::getProvider()->retrieveByCredentials(['email' => $id]);
            return $user && (string)$user->password === '';
        } catch (\Throwable $e) {
            return false;
        }
    }

    public static function refresh()
    {
        $result = Store::rotate((string)self::param('refresh_token', ''), self::$request->ip());
        if (!$result) {
            throw new ApiError(401, 'refresh_invalid', 'login required');
        }
        self::checkUser($result[0]);
        return ['tokens' => $result[1]];
    }

    public static function logout()
    {
        $row = Store::findByAccess(self::bearer());
        if (!$row && self::param('refresh_token')) {
            $result = Store::rotate((string)self::param('refresh_token'), self::$request->ip());
            $row = $result ? $result[0] : null;
        }
        if ($row) {
            Store::revoke($row->token_id);
        }
        return ['logged_out' => true];
    }

    /** GET auth.devices: 최근에 쓴 것부터. current 는 이 요청의 토큰 */
    public static function devices()
    {
        $current = self::$token ? (int)self::$token->token_id : 0;
        $iso = function ($time) {
            return $time ? \Carbon\Carbon::createFromTimestamp((int)$time, date_default_timezone_get())->toIso8601String() : null;
        };
        $devices = [];
        foreach (Store::devices(Auth::user()->getId()) as $row) {
            $devices[] = [
                'device_srl' => (int)$row->token_id,
                'device_name' => (string)$row->device_name,
                'platform' => (string)$row->platform,
                'created' => $iso($row->created),
                'last_used' => $iso($row->last_used),
                'current' => (int)$row->token_id === $current,
            ];
        }
        return ['devices' => $devices];
    }

    /** POST auth.devices.revoke {device_srl}: 자기 토큰 줄만. 지금 기기면 로그아웃과 같다 */
    public static function revokeDevice()
    {
        $srl = self::intParam('device_srl');
        if ($srl <= 0 || !Store::revokeOwn(Auth::user()->getId(), $srl)) {
            throw new ApiError(404, 'not_found', self::message('not_found'));
        }
        return ['revoked' => true];
    }

    /** GET me: 회원 정보 + 포인트 플러그인을 쓰면(설정 '포인트 기능 사용') 포인트·레벨 (앱 '내 정보' 머리 영역) */
    public static function me()
    {
        $profile = self::profile();
        $handler = Points::handler();
        if ($profile && $handler) {
            $user = Auth::user();
            $pointObj = $handler->getPointObj($user->getId());
            $point = (int)$pointObj->point;
            $profile['point'] = $point;
            // 웹 회원 메뉴·레벨 아이콘과 같은 값 (저장된 레벨이 없으면 포인트로 계산)
            $profile['level'] = isset($pointObj->level) ? (int)$pointObj->level : (int)$handler->getLevelByPoint($point);
            $name = (string)$handler->getConfig()->get('point_name');
            $profile['point_name'] = $name !== '' ? $name : 'point';
        }
        return $profile;
    }

    /** 앱의 member 객체 (비회원이면 null) */
    public static function profile()
    {
        $user = Auth::user();
        if (!$user || !Auth::check()) {
            return null;
        }
        $groups = [];
        foreach ($user->groups as $group) {
            $groups[] = (string)$group->name;
        }
        return [
            'member_srl' => Store::num($user->getId()),
            'user_id' => (string)($user->login_id ?: $user->email),
            'nick_name' => (string)$user->getDisplayName(),
            // 이름 (1.0.20~): XE3 회원에는 실명 항목이 없다
            'user_name' => null,
            'email_address' => $user->email ?: null,
            'profile_image' => self::profileImage($user),
            'groups' => $groups,
            'is_admin' => $user->isAdmin(),
        ];
    }

    public static function profileImage($user)
    {
        if (!$user || !$user->profile_image_id) {
            return null;
        }
        $url = $user->getProfileImage();
        return $url ? Boards::absolute($url) : null;
    }

    public static function noNotify()
    {
        return ['enabled' => false, 'unread' => 0];
    }

    /** 언어 코드(ko, en, ja, zh-TW 등)를 앱 언어 코드로. 앱에 없는 언어면 null */
    public static function appLangCode($code)
    {
        $code = strtolower(str_replace('_', '-', trim((string)$code)));
        $base = explode('-', $code)[0];
        if ($base === 'zh') {
            return preg_match('/-(tw|hk|mo|hant)\b/', $code) ? 'zh-Hant' : 'zh-Hans';
        }
        if ($base === 'jp') {
            return 'ja';
        }
        if ($base === 'pt') {
            return 'pt-BR';
        }
        return in_array($base, ['ko', 'en', 'ja', 'es', 'de', 'fr', 'it', 'vi', 'id'], true) ? $base : null;
    }
}
